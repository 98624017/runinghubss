# RunningHub API 全量覆盖增强版

这是一个面向 Agent 与开发者的 RunningHub 本地知识库入口。

它不是“官网摘要”，而是把官网拆成了：

- **入口导航**
- **主题分册**
- **官网页本地替代页**
- **模型族总览**
- **覆盖矩阵**
- **真实验证记录**
- **可直接运行的联调脚本**

如果你的目标是**不回官网也能完成接入、查询、上传与排障**，从这里开始。

## 先从哪里看

### 1. 想快速判断接入路径

先读：

- `references/00-overview.md`
- `references/02-api-concepts.md`

适合：

- 不确定该走 ComfyUI、快捷创作，还是标准模型 API
- 不知道 `workflowId`、`webappId`、`quickCreateCode`、`nodeInfoList` 的区别

### 2. 想确认官网是否已经被本地覆盖

先读：

- `references/10-api-index.md`
- `references/11-api-matrix.md`

适合：

- 你想查某个官网页面本地落在哪个文件
- 你想确认某个 API / schema / 说明页是否已收录

### 3. 想直接写调用代码

按场景跳转：

- 账户与鉴权：`references/01-auth-and-account.md`
- ComfyUI 基础：`references/03-comfyui-workflow-basics.md`
- ComfyUI 高级：`references/04-comfyui-workflow-advanced.md`
- 快捷创作：`references/05-quick-create.md`
- 上传：`references/06-uploads.md`
- 任务状态 / 结果 / webhook：`references/07-task-status-results-webhook.md`
- 排障：`references/08-errors-and-debugging.md`
- 最佳实践：`references/09-best-practices.md`
- Python SDK：`references/13-python-sdk.md`
- Node SDK：`references/14-node-sdk.md`
- 四应用真实闭环：`references/15-ai-app-validation.md`

### 4. 想查某个模型族

直接去：

- `references/models/`

这里已经把官网里的标准模型 API 按家族聚合，例如：

- 海螺 AI
- 全能视频 S / V
- 可灵 2.5 / 2.6 / o1
- 万象 2.6
- Vidu
- 全能图片 / 全能图片 G
- seedream

### 5. 想找官网某一页的本地替代

直接去：

- 官方说明页本地版：`references/docs/`
- 官方接口页本地版：`references/endpoints/`
- 官方 Schema 页本地版：`references/schemas/`

这些文件会保留：

- 官方来源地址
- 页面 ID
- 结构化摘要
- 官网原文归档

## 推荐使用顺序

### 新项目接入

1. `references/00-overview.md`
2. `references/01-auth-and-account.md`
3. `references/02-api-concepts.md`
4. 按场景进入 `03` / `04` / `05`
5. 再读 `06`、`07`、`08`

### 线上问题排查

1. `references/08-errors-and-debugging.md`
2. `references/12-verified-findings.md`
3. 对应的 `references/endpoints/*.md`
4. 必要时再回看 `references/schemas/*.md`

### 某个官网页面查替代页

1. `references/10-api-index.md`
2. `references/11-api-matrix.md`
3. 对应本地 `docs/`、`endpoints/`、`schemas/`

## 真实验证入口

已知最有价值的实测结论，集中放在：

- `references/12-verified-findings.md`

当前至少已验证：

- 账户接口成功返回
- 上传接口成功返回
- 状态接口对非法 / 不存在 `taskId` 的行为
- 部分接口对 Header / Body 鉴权依赖的差异
- V2 查询接口的错误返回形状
- 四个页面型 AI 应用的真实闭环
- `1994388299756212225` 的 Python / Node 双 SDK 闭环
- `2023563076041183233` 在 `2k` 与 `1k` 档位下的余额差异

## 可直接运行的脚本

### 最小联调

- `scripts/check_account.sh`
- `scripts/upload_file.sh`
- `scripts/query_task.sh`
- `scripts/query_result.sh`

### 烟雾验证

- `scripts/smoke/check_headers.sh`
- `scripts/smoke/verify_upload_roundtrip.sh`

### 四应用真实验证

- `scripts/validate/run_python_app_validation.sh`
- `scripts/validate/run_node_app_validation.sh`
- `scripts/validate/build_validation_summary.py`

### 全量收集与重建

- `scripts/collect/build_inventory.py`
- `scripts/collect/sync_official_pages.py`
- `scripts/collect/sync_reference.py`

## 来源标记说明

本知识库中的关键结论都会尽量带来源标记：

- `[官网明确]`：官网原始信息
- `[真实验证]`：已用真实 API 调用验证
- `[交叉整理]`：来自多个官网页面的合并整理
- `[推断建议]`：工程实践建议，不等同于官方承诺

## 何时用这个 Skill

- 你要接入 RunningHub API
- 你要替代官网查开发资料
- 你要定位某个模型族或某个接口页
- 你要弄清 `nodeInfoList`、上传回填、轮询、webhook
- 你在处理 `APIKEY_*`、`TOKEN_INVALID`、`PARAMS_INVALID` 等错误

## 何时不要用这个 Skill

- 你只是在写提示词，不涉及 API 接入
- 你在调试 RunningHub 网页前端，而不是 OpenAPI
- 你要接的是别家的模型平台，而不是 RunningHub

---

# 00-Overview

# RunningHub API 全景入口

## 这套知识库解决什么问题

- [交叉整理] 官网信息是按页面散落的，这里把它整理成“接入路径 + 主题分册 + 逐页替代页 + 实测记录”。
- [交叉整理] 目标不是摘要官网，而是让开发者在不打开官网的情况下也能完成接入。

## 三条主要接入路径

### 1. ComfyUI 工作流 API

- [官网明确] 典型接口：`POST /task/openapi/create`
- [官网明确] 关键前置：已有 `workflowId`
- [官网明确] 适合：你已经在 RunningHub 平台维护自己的工作流
- [交叉整理] 优点：控制力最强，适合长期产品化

### 2. 快捷创作 API

- [官网明确] 典型接口：`POST /task/openapi/quick-ai-app/run`
- [官网明确] 关键前置：已有 `webappId`、`quickCreateCode`
- [官网明确] 适合：复用平台现成模块页能力
- [交叉整理] 优点：页面里能直接拿示例，接入速度快

### 3. 标准模型 API

- [官网明确] 官网当前收录了大量标准模型端点，覆盖视频与图片生成多个模型族。
- [交叉整理] 适合：你明确知道要调用某个具体模型，不依赖工作流页面。
- [交叉整理] 建议先看 `references/models/` 再进入对应 `references/endpoints/*.md`

## 推荐接入顺序

1. [交叉整理] 先做账号可用性检查
2. [交叉整理] 再确认你走哪条接入路径
3. [交叉整理] 如果涉及文件输入，先打上传接口
4. [交叉整理] 再发起任务
5. [交叉整理] 最后处理状态轮询、结果查询或 webhook

## 最小联调路径

### 最稳妥起步

1. `scripts/check_account.sh`
2. `scripts/smoke/check_headers.sh`
3. `scripts/upload_file.sh`
4. `scripts/smoke/verify_upload_roundtrip.sh`

### 进入任务链路前

- [官网明确] 如果你走 ComfyUI 工作流，目标工作流必须先在网页端成功跑过至少一次。
- [交叉整理] 如果你还没确认参数来源，不要急着调任务接口，先看 `references/02-api-concepts.md`

## 你应该先读哪些文件

- 账户与鉴权：`references/01-auth-and-account.md`
- 核心概念：`references/02-api-concepts.md`
- 工作流基础：`references/03-comfyui-workflow-basics.md`
- 工作流高级能力：`references/04-comfyui-workflow-advanced.md`
- 快捷创作：`references/05-quick-create.md`
- 上传：`references/06-uploads.md`
- 任务生命周期：`references/07-task-status-results-webhook.md`
- 排障：`references/08-errors-and-debugging.md`
- 最佳实践：`references/09-best-practices.md`
- 实测结论：`references/12-verified-findings.md`

## 什么时候查逐页替代页

- [交叉整理] 当你想看官网某一页的“本地等价物”时，去 `references/docs/`、`references/endpoints/`、`references/schemas/`
- [交叉整理] 当你不确定有没有漏页时，去 `references/10-api-index.md` 与 `references/11-api-matrix.md`


---

# 01-Auth-And-Account

# 鉴权与账号校验

## 先记住结论

- [真实验证] `POST /uc/openapi/accountStatus` 可以作为首个最小联调接口。
- [真实验证] 对账户接口来说，**Body 里的 `apikey` 是必要的**；仅传 `Authorization` Header 不够。
- [真实验证] 仅传 Body 中的 `apikey`，不传 `Authorization` Header，也能成功返回账户信息。

## 推荐最小联调接口

- 方法：`POST`
- 路径：`/uc/openapi/accountStatus`
- 作用：
  - [官网明确] 校验账号是否支持 API
  - [官网明确] 返回账户类型、剩余 RH 币、当前任务数
  - [交叉整理] 这是最省资源、最适合第一步接通的接口

## 实际鉴权行为

### 官网写法

- [官网明确] 文档常写：
  - Header：`Authorization: Bearer <API_KEY>`
  - Body：`apikey` 或 `apiKey`

### 实测结果

- [真实验证] `accountStatus`：
  - Header + Body：成功
  - 仅 Header：失败，返回 `1601 param apiKey is required`
  - 仅 Body：成功

### 开发建议

- [交叉整理] 不要臆测“全站接口都只认 Header”
- [推断建议] 最稳妥的工程实践仍然是：**Header 与 Body 都按页面示例传**
- [交叉整理] 但若你遇到账户接口异常，优先检查 Body 是否带了 `apikey`

## 最小请求

```bash
curl -X POST 'https://www.runninghub.cn/uc/openapi/accountStatus' \
  -H 'Host: www.runninghub.cn' \
  -H 'Content-Type: application/json' \
  -d "{\"apikey\":\"${RUNNINGHUB_API_KEY}\"}"
```

## 已验证响应

```json
{
  "code": 0,
  "msg": "success",
  "data": {
    "remainCoins": "76600",
    "currentTaskCounts": "0",
    "remainMoney": null,
    "currency": null,
    "apiType": "NORMAL"
  }
}
```

## 关键字段怎么用

- `remainCoins`
  - [官网明确] 剩余 RH 币
  - [交叉整理] 可用来判断是否需要先充值或切企业模式
- `currentTaskCounts`
  - [官网明确] 当前运行中的任务数
  - [交叉整理] 可作为并发占用观察指标
- `apiType`
  - [官网明确] API 类型
  - [真实验证] 当前实测账号返回 `NORMAL`

## 常见失败

- `801 APIKEY_UNSUPPORTED_FREE_USER`
  - [官网明确] 免费用户不支持 API
- `802 APIKEY_UNAUTHORIZED`
  - [官网明确] API Key 无效或失效
- `1601 param apiKey is required`
  - [真实验证] 账户接口缺少 Body 中的 `apikey`

## 推荐检查顺序

1. [交叉整理] 先跑账户接口
2. [交叉整理] 成功后再测上传或任务接口
3. [交叉整理] 如果账户接口都不通，不要继续调任务链路


---

# 02-Api-Concepts

# 核心概念与参数来源

## 最容易混淆的几个概念

### `workflowId`

- [官网明确] ComfyUI 工作流模板 ID
- [官网明确] 可从 RunningHub 工作流页面获取
- [交叉整理] 你要走 `/task/openapi/create` 时，通常需要它

### `webappId`

- [官网明确] 快捷创作应用 ID
- [官网明确] 通常从快捷创作模块页面的 API 示例中获取
- [交叉整理] 你要走 `/task/openapi/quick-ai-app/run` 时，通常需要它

### `quickCreateCode`

- [官网明确] 快捷创作模块代码
- [交叉整理] 这不是让你手写猜出来的，应该从页面“调用 API”示例拿

### `taskId`

- [官网明确] 任务创建后返回的唯一任务 ID
- [交叉整理] 后续状态查询、结果查询、webhook 去重都会依赖它

### `nodeInfoList`

- [官网明确] 动态改参列表
- [交叉整理] 它是 RunningHub 接入里最核心、也最容易错的结构之一

## `nodeInfoList` 到底是什么

一个典型项通常长这样：

```json
{
  "nodeId": "6",
  "fieldName": "text",
  "fieldValue": "1 girl in classroom"
}
```

含义：

- `nodeId`
  - [官网明确] 节点编号
- `fieldName`
  - [官网明确] 节点输入字段名
- `fieldValue`
  - [官网明确] 新值

## `nodeInfoList` 的参数从哪来

1. [官网明确] 在工作流界面看节点右上角数字，拿到 `nodeId`
2. [官网明确] 在 API 格式工作流 JSON 的 `inputs` 里找到对应字段名，拿到 `fieldName`
3. [交叉整理] 再把你自己的实际输入写到 `fieldValue`

## 上传后到底填什么

- [官网明确] 上传接口会返回：
  - `download_url`
  - `fileName`
- [交叉整理] 任务接口里通常应该回填 `fileName`
- [真实验证] 上传接口确实会返回带签名的 `download_url` 和稳定的 `fileName`
- [推断建议] 不要把 `download_url` 当成任务输入的主字段，优先用 `fileName`

## 常见字段命名差异

- [官网明确] 有的接口用 `apikey`
- [官网明确] 有的接口用 `apiKey`
- [交叉整理] 这是 RunningHub 接口的一处不统一点
- [推断建议] 写 SDK 时不要硬编码一个统一字段名，应该按接口页面区分

## 接入路径决策树

### 你已经有 `workflowId`

- [交叉整理] 走 ComfyUI 工作流 API

### 你只有快捷创作模块页面

- [交叉整理] 走快捷创作 API

### 你已经确定要打某个标准模型端点

- [交叉整理] 先看 `references/models/`，再进入对应 `references/endpoints/*.md`

## 最后一个关键前置

- [官网明确] 目标工作流必须先在网页端成功运行过至少一次
- [交叉整理] 如果这一步没做，即使请求格式没错，也可能出现“看似莫名其妙”的失败


---

# 03-Comfyui-Workflow-Basics

# ComfyUI 工作流基础接入

## 适用场景

- [官网明确] 你已经有可用的 `workflowId`
- [交叉整理] 你希望稳定复用自己的工作流，而不是完全依赖平台现成模块

## 最小前置条件

1. [官网明确] 拿到 `workflowId`
2. [官网明确] 工作流在网页端至少成功运行过一次
3. [交叉整理] 明确本次是否需要改参

## 基础调用方式

- [官网明确] 典型接口：`POST /task/openapi/create`
- [官网明确] 简易模式等价于“按网页默认参数直接点运行”

## 最小请求体

```json
{
  "apiKey": "your-api-key",
  "workflowId": "1904136902449209346"
}
```

## 基础接入顺序

1. [交叉整理] 先确认账号与 Key 可用
2. [交叉整理] 再确认工作流能在网页正常跑通
3. [交叉整理] 如果需要图片 / 音频 / 视频输入，先上传资源
4. [交叉整理] 再发起任务
5. [交叉整理] 通过状态接口或 webhook 接收后续结果

## 返回里最重要的字段

- `taskId`
  - [官网明确] 任务 ID
- `taskStatus`
  - [官网明确] 任务状态
- `netWssUrl`
  - [官网明确] 某些场景会返回
- `clientId`
  - [官网明确] 某些场景会返回

## 什么时候还不该进入高级模式

- [交叉整理] 如果你连最小任务都还没成功提交，不要先折腾 `nodeInfoList`
- [交叉整理] 基础模式跑通之后，再引入动态参数替换

## 最小联调建议

- [推断建议] 第一条工作流任务尽量选：
  - 默认参数可直接运行
  - 不需要上传大文件
  - 运行快、成本低

## 对应深读文件

- 高级动态改参：`references/04-comfyui-workflow-advanced.md`
- 上传：`references/06-uploads.md`
- 任务查询：`references/07-task-status-results-webhook.md`


---

# 04-Comfyui-Workflow-Advanced

# ComfyUI 工作流高级调用

## 高级模式解决什么问题

- [官网明确] 通过 `nodeInfoList` 在提交任务前替换默认参数
- [交叉整理] 这是把网页工作流变成程序化 API 能力的关键

## 高级请求体典型结构

```json
{
  "apiKey": "your-api-key",
  "workflowId": "1904136902449209346",
  "nodeInfoList": [
    {
      "nodeId": "6",
      "fieldName": "text",
      "fieldValue": "1 girl in classroom"
    },
    {
      "nodeId": "3",
      "fieldName": "seed",
      "fieldValue": "1231231"
    }
  ]
}
```

## `nodeInfoList` 高风险点

### 1. `nodeId` 填错

- [官网明确] 节点编号必须对应工作流真实节点
- [官网明确] 填错常见报错：`803 APIKEY_INVALID_NODE_INFO`

### 2. `fieldName` 填错

- [官网明确] 必须与 API 格式工作流中该节点的 `inputs` key 一致

### 3. `fieldValue` 类型不匹配

- [交叉整理] 有些字段是字符串，有些是整型、布尔型或资源路径

### 4. 改了前端专属字段

- [官网明确] 某些前端逻辑字段在 API 中不可用
- [交叉整理] 如果 API 格式工作流中找不到对应字段，就别强行传

## 官方特别提醒

- [官网明确] API 调用会强制重置 `seed`
- [交叉整理] 如果你要保持种子值，必须显式把 `seed` 放进 `nodeInfoList`

## 高级可选参数

### `webhookUrl`

- [官网明确] 任务完成后平台会主动回调
- [交叉整理] 适合生产环境异步处理

### `workflow`

- [官网明确] 可以直接传完整工作流 JSON 字符串
- [官网明确] 指定后会忽略 `workflowId`

### `instanceType`

- [官网明确] 可指定实例类型

### `usePersonalQueue`

- [官网明确] 仅对独占类型 API Key 生效

## 高级模式推荐顺序

1. [交叉整理] 先用基础模式跑通
2. [交叉整理] 再只改一个字段验证
3. [交叉整理] 最后逐步扩大到完整 `nodeInfoList`

## 开发建议

- [推断建议] 为 `nodeInfoList` 构造做独立函数，不要散落在业务逻辑里
- [推断建议] 对 `fieldName`、`nodeId` 做静态配置，避免线上手拼
- [推断建议] 对高频资源字段统一封装上传 → 回填流程


---

# 05-Quick-Create

# 快捷创作接入

## 什么时候该走快捷创作

- [官网明确] 当你面对的是 RunningHub 平台里的某个“快捷创作”模块页
- [交叉整理] 当页面本身已经给你现成的 API 示例，而你不想自己维护底层工作流

## 核心接口

- [官网明确] `POST /task/openapi/quick-ai-app/run`

## 关键入参

- `webappId`
  - [官网明确] 快捷创作应用 ID
- `apiKey`
  - [官网明确] API Key
- `quickCreateCode`
  - [官网明确] 快捷创作代码
- `nodeInfoList`
  - [官网明确] 参数列表

## 参数最可靠的来源

1. [官网明确] 登录 RunningHub
2. [官网明确] 进入目标快捷创作模块页
3. [官网明确] 点击“调用 API”
4. [交叉整理] 直接复制页面给出的示例参数

## 和工作流 API 的主要区别

- [交叉整理] 快捷创作更偏“页面能力映射”
- [交叉整理] 工作流 API 更偏“自有工作流编排”
- [官网明确] 快捷创作 `nodeInfoList` 中常带：
  - `nodeName`
  - `fieldType`
  - `description`

## 开发建议

- [推断建议] 不要手工猜 `quickCreateCode`
- [推断建议] 不要把快捷创作与 ComfyUI 工作流参数结构混用
- [交叉整理] 如果一个需求既能走快捷创作也能走工作流，优先选你更容易稳定维护的一条

## 返回关注点

- [官网明确] 常见返回会带：
  - `taskId`
  - `netWssUrl`
  - `clientId`
  - `taskStatus`
  - `promptTips`

## 推荐阅读顺序

1. `references/02-api-concepts.md`
2. 本页
3. `references/07-task-status-results-webhook.md`
4. 对应 `references/endpoints/*.md`


---

# 06-Uploads

# 文件上传与回填

## 推荐接口

- [官网明确] `POST /openapi/v2/media/upload/binary`

## 为什么上传是单独一层

- [交叉整理] 图生图、音频、视频、压缩包等输入场景经常先上传，再发任务
- [交叉整理] 上传成功不代表任务一定成功，但上传失败时后续任务一定跑不通

## 已验证行为

- [真实验证] 上传一个 1×1 PNG 成功
- [真实验证] 返回结构中包含：
  - `code`
  - `msg`
  - `data.type`
  - `data.download_url`
  - `data.fileName`
  - `data.size`

## 关键结论

- [交叉整理] 提交任务时通常要回填 `fileName`
- [推断建议] 不要把 `download_url` 当作任务主输入值，优先用 `fileName`

## 实测返回摘要

```json
{
  "code": 0,
  "msg": "success",
  "data": {
    "type": "image",
    "fileName": "openapi/xxxxxxxx.png",
    "size": "68",
    "download_url": "https://..."
  }
}
```

## 常见回填示例

### 图片

```json
{
  "nodeId": "14",
  "fieldName": "image",
  "fieldValue": "api/9d77b8530f8b3591edc5c4e8f3f55b2cf0960bb2ca35c04e32c1677687866576.png"
}
```

### 音频

```json
{
  "nodeId": "2",
  "fieldName": "audio",
  "fieldValue": "api/7a2f4c8d1e5b9g3h6j0k2l7m4n8p1q3r5s9t0u2v4w6x8y0z1.mp3"
}
```

### 视频

```json
{
  "nodeId": "7",
  "fieldName": "video",
  "fieldValue": "api/14c585a56d8f7c3b9c1ad3c4f8edc93a9fd9f79e21b4d10afd811322bf65f3c2.mp4"
}
```

## 最小联调建议

1. [交叉整理] 先用极小文件验证上传
2. [交叉整理] 确认拿到了 `fileName`
3. [交叉整理] 再把这个值回填进任务请求

## 常见问题

- [官网明确] `808 APIKEY_UPLOAD_FAILED`
- [官网明确] `809 APIKEY_FILE_SIZE_EXCEEDED`
- [推断建议] 如果你上传成功但任务仍报资源问题，优先检查回填的是不是 `fileName`


---

# 07-Task-Status-Results-Webhook

# 任务状态、结果与 webhook

## 任务生命周期

```text
校验账号
  ↓
上传资源（如需要）
  ↓
创建任务
  ↓
查状态 / 等 webhook
  ↓
查结果
```

## 查询状态

- [官网明确] 接口：`POST /task/openapi/status`

### 已验证行为

- [真实验证] `taskId=0` 返回：

```json
{
  "code": 301,
  "msg": "taskId must be positive",
  "data": null
}
```

- [真实验证] 不存在的正整数 `taskId` 返回：

```json
{
  "code": 807,
  "msg": "APIKEY_TASK_NOT_FOUND",
  "data": null
}
```

### 鉴权差异

- [真实验证] 对状态接口来说：
  - 仅 Header，不传 Body 中 `apiKey`，在正整数不存在任务场景下返回 `301 must not be blank`
  - 仅 Body 中 `apiKey`，可以返回 `807 APIKEY_TASK_NOT_FOUND`
- [交叉整理] 这说明状态接口更依赖 Body 中的 `apiKey`

## 查询结果

- [官网明确] 接口：`POST /task/openapi/outputs`

### 官网成功结构

- [官网明确] 成功时 `data` 通常是结果数组
- [官网明确] 元素中常见字段：
  - `fileUrl`
  - `fileType`
  - `taskCostTime`
  - `nodeId`
  - `consumeCoins`

### 已验证行为

- [真实验证] 对不存在的正整数 `taskId`，返回：

```json
{
  "code": 807,
  "msg": "APIKEY_TASK_NOT_FOUND",
  "data": null
}
```

## V2 查询接口

- [官网明确] 接口：`POST /openapi/v2/query`

### 已验证行为

- [真实验证] 带 Authorization Header 查询不存在任务时，返回结构不是 `code/msg/data`，而是：
  - `taskId`
  - `status`
  - `errorCode`
  - `errorMessage`
  - `results`
  - `clientId`
  - `promptTips`
  - `failedReason`
  - `usage`

- [真实验证] 不带鉴权时，返回：

```json
{
  "code": 412,
  "msg": "TOKEN_INVALID"
}
```

## webhook

- [官网明确] 创建任务时可传 `webhookUrl`
- [官网明确] 任务完成后会回调 `TASK_END`
- [官网明确] `eventData` 会携带类似结果查询接口的数据

## 工程建议

- [交叉整理] 调试阶段优先轮询，生产环境优先 webhook
- [推断建议] webhook 接口收到请求后应尽快返回 200，再异步处理
- [推断建议] 用 `taskId` 做幂等键，避免重试导致重复消费


---

# 08-Errors-And-Debugging

# 错误码与排障路径

## 最高频错误码

- [官网明确] `301 PARAMS_INVALID`
- [官网明确] `380 WORKFLOW_NOT_EXISTS`
- [官网明确] `412 TOKEN_INVALID`
- [官网明确] `415 TASK_INSTANCE_MAXED`
- [官网明确] `801 APIKEY_UNSUPPORTED_FREE_USER`
- [官网明确] `802 APIKEY_UNAUTHORIZED`
- [官网明确] `803 APIKEY_INVALID_NODE_INFO`
- [官网明确] `804 APIKEY_TASK_IS_RUNNING`
- [官网明确] `805 APIKEY_TASK_STATUS_ERROR`
- [官网明确] `807 APIKEY_TASK_NOT_FOUND`
- [官网明确] `808 APIKEY_UPLOAD_FAILED`
- [官网明确] `809 APIKEY_FILE_SIZE_EXCEEDED`
- [官网明确] `813 APIKEY_TASK_IS_QUEUED`

## 最推荐的排障顺序

### 第一步：先查 URL

- [官网明确] `412 TOKEN_INVALID` 常见原因是接口路径拼错
- [交叉整理] 这类问题不是“密钥错”，而是“你请求了不存在的 API 地址”

### 第二步：再查账号与 Key

- [交叉整理] 优先跑账户接口
- [真实验证] 账户接口只传 Body 里的 `apikey` 就能成功
- [交叉整理] 如果账户接口都不通，后面所有任务接口都没有排查价值

### 第三步：再查业务前置

- [官网明确] 工作流是否存在
- [官网明确] 工作流是否网页端先跑通过一次

### 第四步：最后查 `nodeInfoList`

- [官网明确] `803 APIKEY_INVALID_NODE_INFO` 往往意味着：
  - `nodeId` 不对
  - `fieldName` 不对
  - `fieldValue` 类型不对

## 三个高发坑

### 1. 把 `download_url` 回填成任务输入

- [交叉整理] 正确做法一般是回填上传返回的 `fileName`

### 2. 忽略字段命名差异

- [官网明确] 有的接口要 `apikey`
- [官网明确] 有的接口要 `apiKey`

### 3. 把前端逻辑字段塞进 API

- [官网明确] 某些字段在 API 格式工作流中并不存在
- [交叉整理] 找不到就不要传

## 真实验证里发现的有用信号

- [真实验证] `accountStatus` 缺少 Body `apikey` 会报 `1601 param apiKey is required`
- [真实验证] `status` 接口对 `taskId=0` 会先报参数错误
- [真实验证] `status` 与 `outputs` 对不存在的正整数 `taskId` 会报 `807`
- [真实验证] `openapi/v2/query` 的错误结构与旧接口不一样

## 排障时该记录什么

- [推断建议] 至少记录：
  - 接口路径
  - `workflowId` / `webappId`
  - `taskId`
  - `code` / `msg`
  - `errorCode` / `errorMessage`
  - 失败时的 `failedReason`

- [推断建议] 不要把完整 API Key 打进日志


---

# 09-Best-Practices

# 开发最佳实践

## 先用低成本路径打通

- [交叉整理] 第一阶段不要急着做完整生成链路
- [推断建议] 推荐顺序：
  1. 账户接口
  2. Header / Body 鉴权差异验证
  3. 上传接口
  4. 状态 / 结果查询错误场景
  5. 最后才做真实任务创建

## 接口封装建议

### 1. 不要写“万能请求函数”就以为万事大吉

- [交叉整理] RunningHub 的一些接口在 `apikey` / `apiKey` 命名上不统一
- [推断建议] SDK 层要允许每个接口定义自己的 Body 字段映射

### 2. 把上传与回填封成一个流程

- [交叉整理] 最容易错的地方不是上传本身，而是把结果回填到任务请求
- [推断建议] 封成：

```text
本地文件 → 上传 → 拿 fileName → 写入 nodeInfoList → 发任务
```

### 3. `nodeInfoList` 不要散写

- [推断建议] 抽成构造器或模板函数
- [推断建议] 用配置保存 `nodeId` 与 `fieldName`

## 重试与轮询建议

- [官网明确] 任务可能出现 `QUEUED`、`RUNNING`、`FAILED`、`SUCCESS`
- [交叉整理] 对轮询来说，不要把 `QUEUED` / `RUNNING` 当成错误
- [推断建议] 轮询间隔可采用渐进退避，避免高频打查询接口

## webhook 建议

- [交叉整理] 生产环境优先 webhook，调试优先轮询
- [推断建议] webhook 回调要快速返回，异步入队处理
- [推断建议] 以 `taskId` 做幂等去重

## 文档使用建议

- [交叉整理] 想按官网页面定位时，先看 `10-api-index.md`
- [交叉整理] 想看主题知识时，先看 00~09
- [交叉整理] 想看已证实结论时，先看 `12-verified-findings.md`

## 团队协作建议

- [推断建议] 每新增一个实际使用的端点，都顺手把真实返回写进 `12-verified-findings.md`
- [推断建议] 每次官网 `llms.txt` 变更后，都重跑 `scripts/collect/sync_official_pages.py`


---

# 10-Api-Index

# RunningHub 官网页面总索引

- [交叉整理] 本页按 `llms.txt` 全量生成，用于确认官网页面在本地知识库中的归宿。
- [官网明确] 页面总数：`110`
- [官网明确] API 页：`73`
- [官网明确] 文档页：`10`
- [官网明确] Schema 页：`27`

## 文档页

- [官网明确] `开始` → `references/docs/7997222-开始.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/doc-7997222.md`
  - 分类：`未分类`
- [官网明确] `更新日志` → `references/docs/7348569-更新日志.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/doc-7348569.md`
  - 分类：`未分类`
- [官网明确] `关于nodeInfoList` → `references/docs/6332955-关于nodeInfoList.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/doc-6332955.md`
  - 分类：`指引`
- [官网明确] `原生ComfyUI接口支持` → `references/docs/6768545-原生ComfyUI接口支持.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/doc-6768545.md`
  - 分类：`指引`
- [官网明确] `接口错误码说明` → `references/docs/6913922-接口错误码说明.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/doc-6913922.md`
  - 分类：`指引`
- [官网明确] `AI应用完整接入示例` → `references/docs/7525194-AI应用完整接入示例.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/doc-7525194.md`
  - 分类：`接入示例`
- [官网明确] `AI应用完整接入示例高阶版` → `references/docs/7527911-AI应用完整接入示例高阶版.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/doc-7527911.md`
  - 分类：`接入示例`
- [官网明确] `任务进度显示示例` → `references/docs/7533195-任务进度显示示例.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/doc-7533195.md`
  - 分类：`接入示例`
- [官网明确] `工作流完整接入示例` → `references/docs/7534195-工作流完整接入示例.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/doc-7534195.md`
  - 分类：`接入示例`
- [官网明确] `关于快捷创作调用` → `references/docs/7314488-关于快捷创作调用.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/doc-7314488.md`
  - 分类：`快捷创作`

## API 页

- [官网明确] `全能视频S-角色上传` → `references/endpoints/408241882-全能视频S-角色上传.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-408241882.md`
  - 分类：`标准模型 API > 视频生成 > 全能视频 S`
- [官网明确] `全能视频S-官方-文生视频` → `references/endpoints/407727815-全能视频S-官方-文生视频.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-407727815.md`
  - 分类：`标准模型 API > 视频生成 > 全能视频 S`
- [官网明确] `全能视频S-官方-文生视频-pro` → `references/endpoints/407729959-全能视频S-官方-文生视频-pro.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-407729959.md`
  - 分类：`标准模型 API > 视频生成 > 全能视频 S`
- [官网明确] `全能视频S-文生视频-pro` → `references/endpoints/402596999-全能视频S-文生视频-pro.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-402596999.md`
  - 分类：`标准模型 API > 视频生成 > 全能视频 S`
- [官网明确] `全能视频S-图生视频-pro` → `references/endpoints/402603035-全能视频S-图生视频-pro.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-402603035.md`
  - 分类：`标准模型 API > 视频生成 > 全能视频 S`
- [官网明确] `全能视频S-图生视频` → `references/endpoints/402596877-全能视频S-图生视频.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-402596877.md`
  - 分类：`标准模型 API > 视频生成 > 全能视频 S`
- [官网明确] `全能视频S-官方-图生视频` → `references/endpoints/407725706-全能视频S-官方-图生视频.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-407725706.md`
  - 分类：`标准模型 API > 视频生成 > 全能视频 S`
- [官网明确] `全能视频S-官方-图生视频-pro` → `references/endpoints/407736182-全能视频S-官方-图生视频-pro.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-407736182.md`
  - 分类：`标准模型 API > 视频生成 > 全能视频 S`
- [官网明确] `全能视频S-官方-图生视频-支持真人` → `references/endpoints/402608271-全能视频S-官方-图生视频-支持真人.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-402608271.md`
  - 分类：`标准模型 API > 视频生成 > 全能视频 S`
- [官网明确] `全能视频S-文生视频` → `references/endpoints/402607591-全能视频S-文生视频.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-402607591.md`
  - 分类：`标准模型 API > 视频生成 > 全能视频 S`
- [官网明确] `全能视频V3.1-fast-图生视频` → `references/endpoints/402609378-全能视频V3.1-fast-图生视频.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-402609378.md`
  - 分类：`标准模型 API > 视频生成 > 全能视频 V`
- [官网明确] `全能视频V3.1-fast-文生视频` → `references/endpoints/402608928-全能视频V3.1-fast-文生视频.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-402608928.md`
  - 分类：`标准模型 API > 视频生成 > 全能视频 V`
- [官网明确] `全能视频V3.1-pro-文生视频` → `references/endpoints/402610533-全能视频V3.1-pro-文生视频.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-402610533.md`
  - 分类：`标准模型 API > 视频生成 > 全能视频 V`
- [官网明确] `可灵文生视频2.6-pro` → `references/endpoints/407928239-可灵文生视频2.6-pro.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-407928239.md`
  - 分类：`标准模型 API > 视频生成 > 可灵 2.6`
- [官网明确] `可灵图生视频2.6-pro` → `references/endpoints/408093144-可灵图生视频2.6-pro.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-408093144.md`
  - 分类：`标准模型 API > 视频生成 > 可灵 2.6`
- [官网明确] `万相2.6-文生视频` → `references/endpoints/408110289-万相2.6-文生视频.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-408110289.md`
  - 分类：`标准模型 API > 视频生成 > 万象 2.6`
- [官网明确] `万相2.6-图生视频` → `references/endpoints/408124606-万相2.6-图生视频.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-408124606.md`
  - 分类：`标准模型 API > 视频生成 > 万象 2.6`
- [官网明确] `万相2.6-图生视频Flash` → `references/endpoints/408131509-万相2.6-图生视频Flash.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-408131509.md`
  - 分类：`标准模型 API > 视频生成 > 万象 2.6`
- [官网明确] `万相2.6-参考生视频Flash` → `references/endpoints/422326015-万相2.6-参考生视频Flash.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-422326015.md`
  - 分类：`标准模型 API > 视频生成 > 万象 2.6`
  - 摘要：万相2.6-参考生视频Flash是阿里通义万相2.6系列的快速参考生视频模型，支持上传最多5张参考图像，基于参考图的角色身份、风格和场景布局生成新视频。该版本生成速度更快，支持720P/1080P两种分辨率，视频时长可选5秒或10秒，可生成带音频或无声视频，支持单镜头和多镜头叙事模式。
- [官网明确] `万相2.6-参考生视频` → `references/endpoints/422326303-万相2.6-参考生视频.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-422326303.md`
  - 分类：`标准模型 API > 视频生成 > 万象 2.6`
  - 摘要：万相2.6-参考生视频是阿里通义万相2.6系列的参考生视频模型，支持多模态输入（文本/图像/视频）。支持720P/1080P分辨率，支持外部音频输入用于声画对齐。模型可基于参考图像或视频还原角色形象，并参考音色，支持单人表演或多角色互动，同时具备多镜头智能调度能力。
- [官网明确] `Vidu-文生视频-q2` → `references/endpoints/408148153-Vidu-文生视频-q2.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-408148153.md`
  - 分类：`标准模型 API > 视频生成 > Vidu`
- [官网明确] `Vidu-图生视频-q2-pro` → `references/endpoints/408154316-Vidu-图生视频-q2-pro.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-408154316.md`
  - 分类：`标准模型 API > 视频生成 > Vidu`
- [官网明确] `Vidu-图生视频-q2-turbo` → `references/endpoints/408156563-Vidu-图生视频-q2-turbo.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-408156563.md`
  - 分类：`标准模型 API > 视频生成 > Vidu`
- [官网明确] `可灵文生视频2.5-turbo-pro` → `references/endpoints/408162666-可灵文生视频2.5-turbo-pro.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-408162666.md`
  - 分类：`标准模型 API > 视频生成 > 可灵 2.5`
- [官网明确] `可灵图生视频2.5-turbo-pro` → `references/endpoints/408163529-可灵图生视频2.5-turbo-pro.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-408163529.md`
  - 分类：`标准模型 API > 视频生成 > 可灵 2.5`
- [官网明确] `可灵图生视频2.5-turbo-std` → `references/endpoints/408166065-可灵图生视频2.5-turbo-std.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-408166065.md`
  - 分类：`标准模型 API > 视频生成 > 可灵 2.5`
- [官网明确] `可灵文生视频o1` → `references/endpoints/408187333-可灵文生视频o1.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-408187333.md`
  - 分类：`标准模型 API > 视频生成 > 可灵 o1`
- [官网明确] `可灵图生视频o1` → `references/endpoints/408189001-可灵图生视频o1.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-408189001.md`
  - 分类：`标准模型 API > 视频生成 > 可灵 o1`
- [官网明确] `可灵首尾帧生视频o1` → `references/endpoints/408192584-可灵首尾帧生视频o1.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-408192584.md`
  - 分类：`标准模型 API > 视频生成 > 可灵 o1`
- [官网明确] `可灵参考生视频o1` → `references/endpoints/408196005-可灵参考生视频o1.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-408196005.md`
  - 分类：`标准模型 API > 视频生成 > 可灵 o1`
- [官网明确] `可灵视频编辑o1` → `references/endpoints/408197709-可灵视频编辑o1.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-408197709.md`
  - 分类：`标准模型 API > 视频生成 > 可灵 o1`
- [官网明确] `海螺-02-文生视频-标准` → `references/endpoints/408219241-海螺-02-文生视频-标准.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-408219241.md`
  - 分类：`标准模型 API > 视频生成 > 海螺AI`
- [官网明确] `海螺-02-文生视频-pro` → `references/endpoints/408224256-海螺-02-文生视频-pro.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-408224256.md`
  - 分类：`标准模型 API > 视频生成 > 海螺AI`
- [官网明确] `海螺-02-图生视频-标准` → `references/endpoints/408220673-海螺-02-图生视频-标准.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-408220673.md`
  - 分类：`标准模型 API > 视频生成 > 海螺AI`
- [官网明确] `海螺-02-标准` → `references/endpoints/408224304-海螺-02-标准.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-408224304.md`
  - 分类：`标准模型 API > 视频生成 > 海螺AI`
- [官网明确] `海螺-02-pro` → `references/endpoints/408224405-海螺-02-pro.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-408224405.md`
  - 分类：`标准模型 API > 视频生成 > 海螺AI`
- [官网明确] `海螺-02-fast` → `references/endpoints/408224487-海螺-02-fast.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-408224487.md`
  - 分类：`标准模型 API > 视频生成 > 海螺AI`
- [官网明确] `海螺-02-图生视频-pro` → `references/endpoints/408224098-海螺-02-图生视频-pro.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-408224098.md`
  - 分类：`标准模型 API > 视频生成 > 海螺AI`
- [官网明确] `海螺-2.3-图生视频-标准` → `references/endpoints/408222351-海螺-2.3-图生视频-标准.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-408222351.md`
  - 分类：`标准模型 API > 视频生成 > 海螺AI`
- [官网明确] `海螺-2.3-fast-图生视频` → `references/endpoints/408222640-海螺-2.3-fast-图生视频.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-408222640.md`
  - 分类：`标准模型 API > 视频生成 > 海螺AI`
- [官网明确] `海螺-2.3-fast-pro-图生视频` → `references/endpoints/408223267-海螺-2.3-fast-pro-图生视频.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-408223267.md`
  - 分类：`标准模型 API > 视频生成 > 海螺AI`
- [官网明确] `海螺-2.3-图生视频-pro` → `references/endpoints/408223446-海螺-2.3-图生视频-pro.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-408223446.md`
  - 分类：`标准模型 API > 视频生成 > 海螺AI`
- [官网明确] `海螺-2.3-文生视频-标准` → `references/endpoints/408220538-海螺-2.3-文生视频-标准.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-408220538.md`
  - 分类：`标准模型 API > 视频生成 > 海螺AI`
- [官网明确] `海螺-2.3-文生视频-pro` → `references/endpoints/408223898-海螺-2.3-文生视频-pro.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-408223898.md`
  - 分类：`标准模型 API > 视频生成 > 海螺AI`
- [官网明确] `全能图片PRO-官方-文生图` → `references/endpoints/402548497-全能图片PRO-官方-文生图.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-402548497.md`
  - 分类：`标准模型 API > 图片生成 > 全能图片`
- [官网明确] `全能图片PRO-文生图` → `references/endpoints/402580909-全能图片PRO-文生图.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-402580909.md`
  - 分类：`标准模型 API > 图片生成 > 全能图片`
- [官网明确] `全能图片V1-文生图` → `references/endpoints/402574588-全能图片V1-文生图.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-402574588.md`
  - 分类：`标准模型 API > 图片生成 > 全能图片`
- [官网明确] `全能图片PRO-官方-图生图` → `references/endpoints/402566952-全能图片PRO-官方-图生图.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-402566952.md`
  - 分类：`标准模型 API > 图片生成 > 全能图片`
- [官网明确] `全能图片PRO-图生图` → `references/endpoints/402583598-全能图片PRO-图生图.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-402583598.md`
  - 分类：`标准模型 API > 图片生成 > 全能图片`
- [官网明确] `全能图片V1-图生图` → `references/endpoints/402575889-全能图片V1-图生图.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-402575889.md`
  - 分类：`标准模型 API > 图片生成 > 全能图片`
- [官网明确] `全能图片G-1.5-文生图` → `references/endpoints/402595775-全能图片G-1.5-文生图.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-402595775.md`
  - 分类：`标准模型 API > 图片生成 > 全能图片 G`
- [官网明确] `全能图片G-1.5-图生图` → `references/endpoints/402593934-全能图片G-1.5-图生图.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-402593934.md`
  - 分类：`标准模型 API > 图片生成 > 全能图片 G`
- [官网明确] `seedream-v4.5-文生图` → `references/endpoints/408103823-seedream-v4.5-文生图.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-408103823.md`
  - 分类：`标准模型 API > 图片生成 > seedream`
- [官网明确] `seedream-v4-文生图` → `references/endpoints/408105506-seedream-v4-文生图.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-408105506.md`
  - 分类：`标准模型 API > 图片生成 > seedream`
- [官网明确] `seedream-v4.5-图生图` → `references/endpoints/408103923-seedream-v4.5-图生图.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-408103923.md`
  - 分类：`标准模型 API > 图片生成 > seedream`
- [官网明确] `seedream-v4-图生图` → `references/endpoints/408105799-seedream-v4-图生图.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-408105799.md`
  - 分类：`标准模型 API > 图片生成 > seedream`
- [官网明确] `查询任务生成结果 V2` → `references/endpoints/402637109-查询任务生成结果-V2.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-402637109.md`
  - 分类：`标准模型 API`
- [官网明确] `发起AI应用任务` → `references/endpoints/279098421-发起AI应用任务.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-279098421.md`
  - 分类：`AI 应用`
  - 摘要：在AI应用详情页中可查看示例nodeInfoList
- [官网明确] `获取AI应用API调用示例` → `references/endpoints/335439604-获取AI应用API调用示例.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-335439604.md`
  - 分类：`AI 应用`
  - 摘要：提供AI应用接口请求调用示例demo，可以参考示例快速发起接口调用
- [官网明确] `发起ComfyUI任务1-简易` → `references/endpoints/276613248-发起ComfyUI任务1-简易.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-276613248.md`
  - 分类：`ComfyUI 工作流`
  - 摘要：该方式运行 workflow，相当于在不改变原有workflow的任何参数的情况下，直接点了一下"运行"按钮。
- [官网明确] `发起ComfyUI任务2-高级` → `references/endpoints/276613249-发起ComfyUI任务2-高级.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-276613249.md`
  - 分类：`ComfyUI 工作流`
  - 摘要：# 发起 ComfyUI 任务（高级）
- [官网明确] `获取工作流Json` → `references/endpoints/276613251-获取工作流Json.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-276613251.md`
  - 分类：`ComfyUI 工作流`
- [官网明确] `取消ComfyUI任务` → `references/endpoints/276613254-取消ComfyUI任务.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-276613254.md`
  - 分类：`ComfyUI 工作流`
- [官网明确] `获取快捷创作-模型库风格参数数据` → `references/endpoints/342821543-获取快捷创作-模型库风格参数数据.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-342821543.md`
  - 分类：`快捷创作`
  - 摘要：该接口用于快捷创作菜单下的文生图模块，目的是获取模型库风格数据，用于调用快捷创作API接口时候的参数填充
- [官网明确] `发起快捷创作任务` → `references/endpoints/342830715-发起快捷创作任务.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-342830715.md`
  - 分类：`快捷创作`
  - 摘要：在快捷创作菜单下选择需要调用的模块页中点击调用API可查看示例，可以获取到webappId、quickCreateCode、nodeInfoList等入参信息，详细请看“关于快捷创作调用”说明
- [官网明确] `查询任务状态` → `references/endpoints/276613252-查询任务状态.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-276613252.md`
  - 分类：`任务查询 & webhook`
- [官网明确] `查询任务生成结果` → `references/endpoints/276613253-查询任务生成结果.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-276613253.md`
  - 分类：`任务查询 & webhook`
- [官网明确] `获取webhook事件详情` → `references/endpoints/276613258-获取webhook事件详情.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-276613258.md`
  - 分类：`任务查询 & webhook`
  - 摘要：此接口旨在帮助调试用户的webhook，通过taskId查询到当前webhook事件的详细状态，拿到事件的id后可以发起重试
- [官网明确] `重新发送指定webhook事件` → `references/endpoints/276613259-重新发送指定webhook事件.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-276613259.md`
  - 分类：`任务查询 & webhook`
  - 摘要：webhookId 为 获取webhook事件详情中返回的id
- [官网明确] `文件上传` → `references/endpoints/402615348-文件上传.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-402615348.md`
  - 分类：`资源上传`
  - 摘要：# 资源文件上传说明
- [官网明确] `上传资源（弃用）` → `references/endpoints/369298135-上传资源（弃用）.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-369298135.md`
  - 分类：`资源上传`
  - 摘要：# RunningHub 资源上传说明（图片、音视、视频、压缩包）
- [官网明确] `上传Lora-获取Lora上传地址` → `references/endpoints/276613257-上传Lora-获取Lora上传地址.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-276613257.md`
  - 分类：`资源上传`
  - 摘要：# RHLoraLoader 专用 LoRA 上传接口说明
- [官网明确] `获取账户信息` → `references/endpoints/276613255-获取账户信息.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/api-276613255.md`
  - 分类：`未分类`

## Schema 页

- [官网明确] `RTaskCreateResponse` → `references/schemas/157370975-RTaskCreateResponse.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/schema-157370975.md`
  - 分类：`未分类`
- [官网明确] `获取工作流Json Request` → `references/schemas/155888520-获取工作流Json-Request.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/schema-155888520.md`
  - 分类：`未分类`
- [官网明确] `获取工作流Json Response` → `references/schemas/155888521-获取工作流Json-Response.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/schema-155888521.md`
  - 分类：`未分类`
- [官网明确] `TaskRunWebappByKeyRequest` → `references/schemas/157370976-TaskRunWebappByKeyRequest.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/schema-157370976.md`
  - 分类：`未分类`
- [官网明确] `发起ComfyUI任务 Request 1` → `references/schemas/155888522-发起ComfyUI任务-Request-1.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/schema-155888522.md`
  - 分类：`未分类`
- [官网明确] `NodeInfo` → `references/schemas/157370977-NodeInfo.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/schema-157370977.md`
  - 分类：`未分类`
- [官网明确] `发起ComfyUI任务 Request 2` → `references/schemas/155888523-发起ComfyUI任务-Request-2.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/schema-155888523.md`
  - 分类：`未分类`
- [官网明确] `发起ComfyUI任务 Request-webhook` → `references/schemas/155888524-发起ComfyUI任务-Request-webhook.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/schema-155888524.md`
  - 分类：`未分类`
- [官网明确] `发起ComfyUI任务 Response` → `references/schemas/155888525-发起ComfyUI任务-Response.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/schema-155888525.md`
  - 分类：`未分类`
- [官网明确] `TaskCreateResponse` → `references/schemas/155888526-TaskCreateResponse.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/schema-155888526.md`
  - 分类：`未分类`
- [官网明确] `查询任务状态 Request` → `references/schemas/155888527-查询任务状态-Request.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/schema-155888527.md`
  - 分类：`未分类`
- [官网明确] `节点输入信息` → `references/schemas/155888528-节点输入信息.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/schema-155888528.md`
  - 分类：`未分类`
- [官网明确] `获取账户信息 Request` → `references/schemas/155888529-获取账户信息-Request.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/schema-155888529.md`
  - 分类：`未分类`
- [官网明确] `上传资源Request` → `references/schemas/155888530-上传资源Request.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/schema-155888530.md`
  - 分类：`未分类`
- [官网明确] `获取webhook事件详情Request` → `references/schemas/155888531-获取webhook事件详情Request.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/schema-155888531.md`
  - 分类：`未分类`
- [官网明确] `重新发送指定webhook Request` → `references/schemas/155888532-重新发送指定webhook-Request.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/schema-155888532.md`
  - 分类：`未分类`
- [官网明确] `R?` → `references/schemas/155888533-R.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/schema-155888533.md`
  - 分类：`未分类`
- [官网明确] `RWorkflowDuplicateResponse` → `references/schemas/155888534-RWorkflowDuplicateResponse.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/schema-155888534.md`
  - 分类：`未分类`
- [官网明确] `RAccountStatusResponse` → `references/schemas/155888535-RAccountStatusResponse.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/schema-155888535.md`
  - 分类：`未分类`
- [官网明确] `WorkflowDuplicateResponse` → `references/schemas/155888536-WorkflowDuplicateResponse.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/schema-155888536.md`
  - 分类：`未分类`
- [官网明确] `AccountStatusResponse` → `references/schemas/155888537-AccountStatusResponse.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/schema-155888537.md`
  - 分类：`未分类`
- [官网明确] `WorkflowDuplicateRequest` → `references/schemas/155888538-WorkflowDuplicateRequest.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/schema-155888538.md`
  - 分类：`未分类`
- [官网明确] `ApiUploadLoraRequest` → `references/schemas/155888539-ApiUploadLoraRequest.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/schema-155888539.md`
  - 分类：`未分类`
- [官网明确] `RString` → `references/schemas/155888540-RString.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/schema-155888540.md`
  - 分类：`未分类`
- [官网明确] `RTaskUploadResponse` → `references/schemas/155888541-RTaskUploadResponse.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/schema-155888541.md`
  - 分类：`未分类`
- [官网明确] `TaskUploadResponse` → `references/schemas/155888542-TaskUploadResponse.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/schema-155888542.md`
  - 分类：`未分类`
- [官网明确] `生成任务提交结果` → `references/schemas/236725850-生成任务提交结果.md`
  - 官方地址：`https://www.runninghub.cn/runninghub-api-doc-cn/schema-236725850.md`
  - 分类：`未分类`


---

# 11-Api-Matrix

# RunningHub 页面覆盖矩阵

| 页面标题 | 类型 | 官方地址 | 本地文件 | 覆盖状态 | 验证状态 | 备注 |
|---|---|---|---|---|---|---|
| 开始 | doc | `https://www.runninghub.cn/runninghub-api-doc-cn/doc-7997222.md` | `references/docs/7997222-开始.md` | 已覆盖 | 待验证 | 未分类 |
| 更新日志 | doc | `https://www.runninghub.cn/runninghub-api-doc-cn/doc-7348569.md` | `references/docs/7348569-更新日志.md` | 已覆盖 | 待验证 | 未分类 |
| 关于nodeInfoList | doc | `https://www.runninghub.cn/runninghub-api-doc-cn/doc-6332955.md` | `references/docs/6332955-关于nodeInfoList.md` | 已覆盖 | 待验证 | 指引 |
| 原生ComfyUI接口支持 | doc | `https://www.runninghub.cn/runninghub-api-doc-cn/doc-6768545.md` | `references/docs/6768545-原生ComfyUI接口支持.md` | 已覆盖 | 待验证 | 指引 |
| 接口错误码说明 | doc | `https://www.runninghub.cn/runninghub-api-doc-cn/doc-6913922.md` | `references/docs/6913922-接口错误码说明.md` | 已覆盖 | 待验证 | 指引 |
| AI应用完整接入示例 | doc | `https://www.runninghub.cn/runninghub-api-doc-cn/doc-7525194.md` | `references/docs/7525194-AI应用完整接入示例.md` | 已覆盖 | 待验证 | 接入示例 |
| AI应用完整接入示例高阶版 | doc | `https://www.runninghub.cn/runninghub-api-doc-cn/doc-7527911.md` | `references/docs/7527911-AI应用完整接入示例高阶版.md` | 已覆盖 | 待验证 | 接入示例 |
| 任务进度显示示例 | doc | `https://www.runninghub.cn/runninghub-api-doc-cn/doc-7533195.md` | `references/docs/7533195-任务进度显示示例.md` | 已覆盖 | 待验证 | 接入示例 |
| 工作流完整接入示例 | doc | `https://www.runninghub.cn/runninghub-api-doc-cn/doc-7534195.md` | `references/docs/7534195-工作流完整接入示例.md` | 已覆盖 | 待验证 | 接入示例 |
| 关于快捷创作调用 | doc | `https://www.runninghub.cn/runninghub-api-doc-cn/doc-7314488.md` | `references/docs/7314488-关于快捷创作调用.md` | 已覆盖 | 待验证 | 快捷创作 |
| 全能视频S-角色上传 | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-408241882.md` | `references/endpoints/408241882-全能视频S-角色上传.md` | 已覆盖 | 待验证 | 标准模型 API > 视频生成 > 全能视频 S |
| 全能视频S-官方-文生视频 | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-407727815.md` | `references/endpoints/407727815-全能视频S-官方-文生视频.md` | 已覆盖 | 待验证 | 标准模型 API > 视频生成 > 全能视频 S |
| 全能视频S-官方-文生视频-pro | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-407729959.md` | `references/endpoints/407729959-全能视频S-官方-文生视频-pro.md` | 已覆盖 | 待验证 | 标准模型 API > 视频生成 > 全能视频 S |
| 全能视频S-文生视频-pro | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-402596999.md` | `references/endpoints/402596999-全能视频S-文生视频-pro.md` | 已覆盖 | 待验证 | 标准模型 API > 视频生成 > 全能视频 S |
| 全能视频S-图生视频-pro | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-402603035.md` | `references/endpoints/402603035-全能视频S-图生视频-pro.md` | 已覆盖 | 待验证 | 标准模型 API > 视频生成 > 全能视频 S |
| 全能视频S-图生视频 | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-402596877.md` | `references/endpoints/402596877-全能视频S-图生视频.md` | 已覆盖 | 待验证 | 标准模型 API > 视频生成 > 全能视频 S |
| 全能视频S-官方-图生视频 | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-407725706.md` | `references/endpoints/407725706-全能视频S-官方-图生视频.md` | 已覆盖 | 待验证 | 标准模型 API > 视频生成 > 全能视频 S |
| 全能视频S-官方-图生视频-pro | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-407736182.md` | `references/endpoints/407736182-全能视频S-官方-图生视频-pro.md` | 已覆盖 | 待验证 | 标准模型 API > 视频生成 > 全能视频 S |
| 全能视频S-官方-图生视频-支持真人 | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-402608271.md` | `references/endpoints/402608271-全能视频S-官方-图生视频-支持真人.md` | 已覆盖 | 待验证 | 标准模型 API > 视频生成 > 全能视频 S |
| 全能视频S-文生视频 | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-402607591.md` | `references/endpoints/402607591-全能视频S-文生视频.md` | 已覆盖 | 待验证 | 标准模型 API > 视频生成 > 全能视频 S |
| 全能视频V3.1-fast-图生视频 | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-402609378.md` | `references/endpoints/402609378-全能视频V3.1-fast-图生视频.md` | 已覆盖 | 待验证 | 标准模型 API > 视频生成 > 全能视频 V |
| 全能视频V3.1-fast-文生视频 | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-402608928.md` | `references/endpoints/402608928-全能视频V3.1-fast-文生视频.md` | 已覆盖 | 待验证 | 标准模型 API > 视频生成 > 全能视频 V |
| 全能视频V3.1-pro-文生视频 | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-402610533.md` | `references/endpoints/402610533-全能视频V3.1-pro-文生视频.md` | 已覆盖 | 待验证 | 标准模型 API > 视频生成 > 全能视频 V |
| 可灵文生视频2.6-pro | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-407928239.md` | `references/endpoints/407928239-可灵文生视频2.6-pro.md` | 已覆盖 | 待验证 | 标准模型 API > 视频生成 > 可灵 2.6 |
| 可灵图生视频2.6-pro | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-408093144.md` | `references/endpoints/408093144-可灵图生视频2.6-pro.md` | 已覆盖 | 待验证 | 标准模型 API > 视频生成 > 可灵 2.6 |
| 万相2.6-文生视频 | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-408110289.md` | `references/endpoints/408110289-万相2.6-文生视频.md` | 已覆盖 | 待验证 | 标准模型 API > 视频生成 > 万象 2.6 |
| 万相2.6-图生视频 | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-408124606.md` | `references/endpoints/408124606-万相2.6-图生视频.md` | 已覆盖 | 待验证 | 标准模型 API > 视频生成 > 万象 2.6 |
| 万相2.6-图生视频Flash | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-408131509.md` | `references/endpoints/408131509-万相2.6-图生视频Flash.md` | 已覆盖 | 待验证 | 标准模型 API > 视频生成 > 万象 2.6 |
| 万相2.6-参考生视频Flash | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-422326015.md` | `references/endpoints/422326015-万相2.6-参考生视频Flash.md` | 已覆盖 | 待验证 | 标准模型 API > 视频生成 > 万象 2.6；万相2.6-参考生视频Flash是阿里通义万相2.6系列的快速参考生视频模型，支持上传最多5张参考图像，基于参考图的角色身份、风格和场景布局生成新视频。该版本生成速度更快，支持720P/1080P两种分辨率，视频时长可选5秒或10秒，可生成带音频或无声视频，支持单镜头和多镜头叙事模式。 |
| 万相2.6-参考生视频 | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-422326303.md` | `references/endpoints/422326303-万相2.6-参考生视频.md` | 已覆盖 | 待验证 | 标准模型 API > 视频生成 > 万象 2.6；万相2.6-参考生视频是阿里通义万相2.6系列的参考生视频模型，支持多模态输入（文本/图像/视频）。支持720P/1080P分辨率，支持外部音频输入用于声画对齐。模型可基于参考图像或视频还原角色形象，并参考音色，支持单人表演或多角色互动，同时具备多镜头智能调度能力。 |
| Vidu-文生视频-q2 | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-408148153.md` | `references/endpoints/408148153-Vidu-文生视频-q2.md` | 已覆盖 | 待验证 | 标准模型 API > 视频生成 > Vidu |
| Vidu-图生视频-q2-pro | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-408154316.md` | `references/endpoints/408154316-Vidu-图生视频-q2-pro.md` | 已覆盖 | 待验证 | 标准模型 API > 视频生成 > Vidu |
| Vidu-图生视频-q2-turbo | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-408156563.md` | `references/endpoints/408156563-Vidu-图生视频-q2-turbo.md` | 已覆盖 | 待验证 | 标准模型 API > 视频生成 > Vidu |
| 可灵文生视频2.5-turbo-pro | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-408162666.md` | `references/endpoints/408162666-可灵文生视频2.5-turbo-pro.md` | 已覆盖 | 待验证 | 标准模型 API > 视频生成 > 可灵 2.5 |
| 可灵图生视频2.5-turbo-pro | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-408163529.md` | `references/endpoints/408163529-可灵图生视频2.5-turbo-pro.md` | 已覆盖 | 待验证 | 标准模型 API > 视频生成 > 可灵 2.5 |
| 可灵图生视频2.5-turbo-std | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-408166065.md` | `references/endpoints/408166065-可灵图生视频2.5-turbo-std.md` | 已覆盖 | 待验证 | 标准模型 API > 视频生成 > 可灵 2.5 |
| 可灵文生视频o1 | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-408187333.md` | `references/endpoints/408187333-可灵文生视频o1.md` | 已覆盖 | 待验证 | 标准模型 API > 视频生成 > 可灵 o1 |
| 可灵图生视频o1 | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-408189001.md` | `references/endpoints/408189001-可灵图生视频o1.md` | 已覆盖 | 待验证 | 标准模型 API > 视频生成 > 可灵 o1 |
| 可灵首尾帧生视频o1 | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-408192584.md` | `references/endpoints/408192584-可灵首尾帧生视频o1.md` | 已覆盖 | 待验证 | 标准模型 API > 视频生成 > 可灵 o1 |
| 可灵参考生视频o1 | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-408196005.md` | `references/endpoints/408196005-可灵参考生视频o1.md` | 已覆盖 | 待验证 | 标准模型 API > 视频生成 > 可灵 o1 |
| 可灵视频编辑o1 | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-408197709.md` | `references/endpoints/408197709-可灵视频编辑o1.md` | 已覆盖 | 待验证 | 标准模型 API > 视频生成 > 可灵 o1 |
| 海螺-02-文生视频-标准 | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-408219241.md` | `references/endpoints/408219241-海螺-02-文生视频-标准.md` | 已覆盖 | 待验证 | 标准模型 API > 视频生成 > 海螺AI |
| 海螺-02-文生视频-pro | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-408224256.md` | `references/endpoints/408224256-海螺-02-文生视频-pro.md` | 已覆盖 | 待验证 | 标准模型 API > 视频生成 > 海螺AI |
| 海螺-02-图生视频-标准 | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-408220673.md` | `references/endpoints/408220673-海螺-02-图生视频-标准.md` | 已覆盖 | 待验证 | 标准模型 API > 视频生成 > 海螺AI |
| 海螺-02-标准 | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-408224304.md` | `references/endpoints/408224304-海螺-02-标准.md` | 已覆盖 | 待验证 | 标准模型 API > 视频生成 > 海螺AI |
| 海螺-02-pro | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-408224405.md` | `references/endpoints/408224405-海螺-02-pro.md` | 已覆盖 | 待验证 | 标准模型 API > 视频生成 > 海螺AI |
| 海螺-02-fast | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-408224487.md` | `references/endpoints/408224487-海螺-02-fast.md` | 已覆盖 | 待验证 | 标准模型 API > 视频生成 > 海螺AI |
| 海螺-02-图生视频-pro | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-408224098.md` | `references/endpoints/408224098-海螺-02-图生视频-pro.md` | 已覆盖 | 待验证 | 标准模型 API > 视频生成 > 海螺AI |
| 海螺-2.3-图生视频-标准 | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-408222351.md` | `references/endpoints/408222351-海螺-2.3-图生视频-标准.md` | 已覆盖 | 待验证 | 标准模型 API > 视频生成 > 海螺AI |
| 海螺-2.3-fast-图生视频 | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-408222640.md` | `references/endpoints/408222640-海螺-2.3-fast-图生视频.md` | 已覆盖 | 待验证 | 标准模型 API > 视频生成 > 海螺AI |
| 海螺-2.3-fast-pro-图生视频 | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-408223267.md` | `references/endpoints/408223267-海螺-2.3-fast-pro-图生视频.md` | 已覆盖 | 待验证 | 标准模型 API > 视频生成 > 海螺AI |
| 海螺-2.3-图生视频-pro | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-408223446.md` | `references/endpoints/408223446-海螺-2.3-图生视频-pro.md` | 已覆盖 | 待验证 | 标准模型 API > 视频生成 > 海螺AI |
| 海螺-2.3-文生视频-标准 | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-408220538.md` | `references/endpoints/408220538-海螺-2.3-文生视频-标准.md` | 已覆盖 | 待验证 | 标准模型 API > 视频生成 > 海螺AI |
| 海螺-2.3-文生视频-pro | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-408223898.md` | `references/endpoints/408223898-海螺-2.3-文生视频-pro.md` | 已覆盖 | 待验证 | 标准模型 API > 视频生成 > 海螺AI |
| 全能图片PRO-官方-文生图 | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-402548497.md` | `references/endpoints/402548497-全能图片PRO-官方-文生图.md` | 已覆盖 | 待验证 | 标准模型 API > 图片生成 > 全能图片 |
| 全能图片PRO-文生图 | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-402580909.md` | `references/endpoints/402580909-全能图片PRO-文生图.md` | 已覆盖 | 待验证 | 标准模型 API > 图片生成 > 全能图片 |
| 全能图片V1-文生图 | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-402574588.md` | `references/endpoints/402574588-全能图片V1-文生图.md` | 已覆盖 | 待验证 | 标准模型 API > 图片生成 > 全能图片 |
| 全能图片PRO-官方-图生图 | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-402566952.md` | `references/endpoints/402566952-全能图片PRO-官方-图生图.md` | 已覆盖 | 待验证 | 标准模型 API > 图片生成 > 全能图片 |
| 全能图片PRO-图生图 | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-402583598.md` | `references/endpoints/402583598-全能图片PRO-图生图.md` | 已覆盖 | 待验证 | 标准模型 API > 图片生成 > 全能图片 |
| 全能图片V1-图生图 | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-402575889.md` | `references/endpoints/402575889-全能图片V1-图生图.md` | 已覆盖 | 待验证 | 标准模型 API > 图片生成 > 全能图片 |
| 全能图片G-1.5-文生图 | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-402595775.md` | `references/endpoints/402595775-全能图片G-1.5-文生图.md` | 已覆盖 | 待验证 | 标准模型 API > 图片生成 > 全能图片 G |
| 全能图片G-1.5-图生图 | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-402593934.md` | `references/endpoints/402593934-全能图片G-1.5-图生图.md` | 已覆盖 | 待验证 | 标准模型 API > 图片生成 > 全能图片 G |
| seedream-v4.5-文生图 | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-408103823.md` | `references/endpoints/408103823-seedream-v4.5-文生图.md` | 已覆盖 | 待验证 | 标准模型 API > 图片生成 > seedream |
| seedream-v4-文生图 | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-408105506.md` | `references/endpoints/408105506-seedream-v4-文生图.md` | 已覆盖 | 待验证 | 标准模型 API > 图片生成 > seedream |
| seedream-v4.5-图生图 | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-408103923.md` | `references/endpoints/408103923-seedream-v4.5-图生图.md` | 已覆盖 | 待验证 | 标准模型 API > 图片生成 > seedream |
| seedream-v4-图生图 | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-408105799.md` | `references/endpoints/408105799-seedream-v4-图生图.md` | 已覆盖 | 待验证 | 标准模型 API > 图片生成 > seedream |
| 查询任务生成结果 V2 | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-402637109.md` | `references/endpoints/402637109-查询任务生成结果-V2.md` | 已覆盖 | 已验证 | 标准模型 API |
| 发起AI应用任务 | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-279098421.md` | `references/endpoints/279098421-发起AI应用任务.md` | 已覆盖 | 待验证 | AI 应用；在AI应用详情页中可查看示例nodeInfoList |
| 获取AI应用API调用示例 | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-335439604.md` | `references/endpoints/335439604-获取AI应用API调用示例.md` | 已覆盖 | 待验证 | AI 应用；提供AI应用接口请求调用示例demo，可以参考示例快速发起接口调用 |
| 发起ComfyUI任务1-简易 | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-276613248.md` | `references/endpoints/276613248-发起ComfyUI任务1-简易.md` | 已覆盖 | 待验证 | ComfyUI 工作流；该方式运行 workflow，相当于在不改变原有workflow的任何参数的情况下，直接点了一下"运行"按钮。 |
| 发起ComfyUI任务2-高级 | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-276613249.md` | `references/endpoints/276613249-发起ComfyUI任务2-高级.md` | 已覆盖 | 待验证 | ComfyUI 工作流；# 发起 ComfyUI 任务（高级） |
| 获取工作流Json | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-276613251.md` | `references/endpoints/276613251-获取工作流Json.md` | 已覆盖 | 待验证 | ComfyUI 工作流 |
| 取消ComfyUI任务 | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-276613254.md` | `references/endpoints/276613254-取消ComfyUI任务.md` | 已覆盖 | 待验证 | ComfyUI 工作流 |
| 获取快捷创作-模型库风格参数数据 | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-342821543.md` | `references/endpoints/342821543-获取快捷创作-模型库风格参数数据.md` | 已覆盖 | 待验证 | 快捷创作；该接口用于快捷创作菜单下的文生图模块，目的是获取模型库风格数据，用于调用快捷创作API接口时候的参数填充 |
| 发起快捷创作任务 | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-342830715.md` | `references/endpoints/342830715-发起快捷创作任务.md` | 已覆盖 | 待验证 | 快捷创作；在快捷创作菜单下选择需要调用的模块页中点击调用API可查看示例，可以获取到webappId、quickCreateCode、nodeInfoList等入参信息，详细请看“关于快捷创作调用”说明 |
| 查询任务状态 | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-276613252.md` | `references/endpoints/276613252-查询任务状态.md` | 已覆盖 | 已验证 | 任务查询 & webhook |
| 查询任务生成结果 | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-276613253.md` | `references/endpoints/276613253-查询任务生成结果.md` | 已覆盖 | 已验证 | 任务查询 & webhook |
| 获取webhook事件详情 | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-276613258.md` | `references/endpoints/276613258-获取webhook事件详情.md` | 已覆盖 | 待验证 | 任务查询 & webhook；此接口旨在帮助调试用户的webhook，通过taskId查询到当前webhook事件的详细状态，拿到事件的id后可以发起重试 |
| 重新发送指定webhook事件 | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-276613259.md` | `references/endpoints/276613259-重新发送指定webhook事件.md` | 已覆盖 | 待验证 | 任务查询 & webhook；webhookId 为 获取webhook事件详情中返回的id |
| 文件上传 | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-402615348.md` | `references/endpoints/402615348-文件上传.md` | 已覆盖 | 已验证 | 资源上传；# 资源文件上传说明 |
| 上传资源（弃用） | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-369298135.md` | `references/endpoints/369298135-上传资源（弃用）.md` | 已覆盖 | 待验证 | 资源上传；# RunningHub 资源上传说明（图片、音视、视频、压缩包） |
| 上传Lora-获取Lora上传地址 | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-276613257.md` | `references/endpoints/276613257-上传Lora-获取Lora上传地址.md` | 已覆盖 | 待验证 | 资源上传；# RHLoraLoader 专用 LoRA 上传接口说明 |
| 获取账户信息 | api | `https://www.runninghub.cn/runninghub-api-doc-cn/api-276613255.md` | `references/endpoints/276613255-获取账户信息.md` | 已覆盖 | 已验证 | 未分类 |
| RTaskCreateResponse | schema | `https://www.runninghub.cn/runninghub-api-doc-cn/schema-157370975.md` | `references/schemas/157370975-RTaskCreateResponse.md` | 已覆盖 | 待验证 | 未分类 |
| 获取工作流Json Request | schema | `https://www.runninghub.cn/runninghub-api-doc-cn/schema-155888520.md` | `references/schemas/155888520-获取工作流Json-Request.md` | 已覆盖 | 待验证 | 未分类 |
| 获取工作流Json Response | schema | `https://www.runninghub.cn/runninghub-api-doc-cn/schema-155888521.md` | `references/schemas/155888521-获取工作流Json-Response.md` | 已覆盖 | 待验证 | 未分类 |
| TaskRunWebappByKeyRequest | schema | `https://www.runninghub.cn/runninghub-api-doc-cn/schema-157370976.md` | `references/schemas/157370976-TaskRunWebappByKeyRequest.md` | 已覆盖 | 待验证 | 未分类 |
| 发起ComfyUI任务 Request 1 | schema | `https://www.runninghub.cn/runninghub-api-doc-cn/schema-155888522.md` | `references/schemas/155888522-发起ComfyUI任务-Request-1.md` | 已覆盖 | 待验证 | 未分类 |
| NodeInfo | schema | `https://www.runninghub.cn/runninghub-api-doc-cn/schema-157370977.md` | `references/schemas/157370977-NodeInfo.md` | 已覆盖 | 待验证 | 未分类 |
| 发起ComfyUI任务 Request 2 | schema | `https://www.runninghub.cn/runninghub-api-doc-cn/schema-155888523.md` | `references/schemas/155888523-发起ComfyUI任务-Request-2.md` | 已覆盖 | 待验证 | 未分类 |
| 发起ComfyUI任务 Request-webhook | schema | `https://www.runninghub.cn/runninghub-api-doc-cn/schema-155888524.md` | `references/schemas/155888524-发起ComfyUI任务-Request-webhook.md` | 已覆盖 | 待验证 | 未分类 |
| 发起ComfyUI任务 Response | schema | `https://www.runninghub.cn/runninghub-api-doc-cn/schema-155888525.md` | `references/schemas/155888525-发起ComfyUI任务-Response.md` | 已覆盖 | 待验证 | 未分类 |
| TaskCreateResponse | schema | `https://www.runninghub.cn/runninghub-api-doc-cn/schema-155888526.md` | `references/schemas/155888526-TaskCreateResponse.md` | 已覆盖 | 待验证 | 未分类 |
| 查询任务状态 Request | schema | `https://www.runninghub.cn/runninghub-api-doc-cn/schema-155888527.md` | `references/schemas/155888527-查询任务状态-Request.md` | 已覆盖 | 待验证 | 未分类 |
| 节点输入信息 | schema | `https://www.runninghub.cn/runninghub-api-doc-cn/schema-155888528.md` | `references/schemas/155888528-节点输入信息.md` | 已覆盖 | 待验证 | 未分类 |
| 获取账户信息 Request | schema | `https://www.runninghub.cn/runninghub-api-doc-cn/schema-155888529.md` | `references/schemas/155888529-获取账户信息-Request.md` | 已覆盖 | 待验证 | 未分类 |
| 上传资源Request | schema | `https://www.runninghub.cn/runninghub-api-doc-cn/schema-155888530.md` | `references/schemas/155888530-上传资源Request.md` | 已覆盖 | 待验证 | 未分类 |
| 获取webhook事件详情Request | schema | `https://www.runninghub.cn/runninghub-api-doc-cn/schema-155888531.md` | `references/schemas/155888531-获取webhook事件详情Request.md` | 已覆盖 | 待验证 | 未分类 |
| 重新发送指定webhook Request | schema | `https://www.runninghub.cn/runninghub-api-doc-cn/schema-155888532.md` | `references/schemas/155888532-重新发送指定webhook-Request.md` | 已覆盖 | 待验证 | 未分类 |
| R? | schema | `https://www.runninghub.cn/runninghub-api-doc-cn/schema-155888533.md` | `references/schemas/155888533-R.md` | 已覆盖 | 待验证 | 未分类 |
| RWorkflowDuplicateResponse | schema | `https://www.runninghub.cn/runninghub-api-doc-cn/schema-155888534.md` | `references/schemas/155888534-RWorkflowDuplicateResponse.md` | 已覆盖 | 待验证 | 未分类 |
| RAccountStatusResponse | schema | `https://www.runninghub.cn/runninghub-api-doc-cn/schema-155888535.md` | `references/schemas/155888535-RAccountStatusResponse.md` | 已覆盖 | 待验证 | 未分类 |
| WorkflowDuplicateResponse | schema | `https://www.runninghub.cn/runninghub-api-doc-cn/schema-155888536.md` | `references/schemas/155888536-WorkflowDuplicateResponse.md` | 已覆盖 | 待验证 | 未分类 |
| AccountStatusResponse | schema | `https://www.runninghub.cn/runninghub-api-doc-cn/schema-155888537.md` | `references/schemas/155888537-AccountStatusResponse.md` | 已覆盖 | 待验证 | 未分类 |
| WorkflowDuplicateRequest | schema | `https://www.runninghub.cn/runninghub-api-doc-cn/schema-155888538.md` | `references/schemas/155888538-WorkflowDuplicateRequest.md` | 已覆盖 | 待验证 | 未分类 |
| ApiUploadLoraRequest | schema | `https://www.runninghub.cn/runninghub-api-doc-cn/schema-155888539.md` | `references/schemas/155888539-ApiUploadLoraRequest.md` | 已覆盖 | 待验证 | 未分类 |
| RString | schema | `https://www.runninghub.cn/runninghub-api-doc-cn/schema-155888540.md` | `references/schemas/155888540-RString.md` | 已覆盖 | 待验证 | 未分类 |
| RTaskUploadResponse | schema | `https://www.runninghub.cn/runninghub-api-doc-cn/schema-155888541.md` | `references/schemas/155888541-RTaskUploadResponse.md` | 已覆盖 | 待验证 | 未分类 |
| TaskUploadResponse | schema | `https://www.runninghub.cn/runninghub-api-doc-cn/schema-155888542.md` | `references/schemas/155888542-TaskUploadResponse.md` | 已覆盖 | 待验证 | 未分类 |
| 生成任务提交结果 | schema | `https://www.runninghub.cn/runninghub-api-doc-cn/schema-236725850.md` | `references/schemas/236725850-生成任务提交结果.md` | 已覆盖 | 待验证 | 未分类 |


---

# 12-Verified-Findings

# 真实验证记录

## 说明

- [真实验证] 本页只记录已经用真实 API 请求验证过的事实
- [交叉整理] 未出现在本页的结论，不代表错误，只代表“尚未进入实测层”

## 2026-03-08：账户接口

### 请求

- 接口：`POST /uc/openapi/accountStatus`

### 结果

- [真实验证] Header + Body：成功
- [真实验证] 仅 Header：失败，`1601 param apiKey is required`
- [真实验证] 仅 Body：成功

### 结论

- [真实验证] 对账户接口来说，Body 里的 `apikey` 是必需条件
- [推断建议] 工程上仍建议 Header 与 Body 都按示例传，避免后续接口差异踩坑

## 2026-03-08：账户接口成功响应

```json
{
  "code": 0,
  "msg": "success",
  "data": {
    "remainCoins": "76600",
    "currentTaskCounts": "0",
    "remainMoney": null,
    "currency": null,
    "apiType": "NORMAL"
  }
}
```

## 2026-03-08：上传接口

### 请求

- 接口：`POST /openapi/v2/media/upload/binary`
- 输入：1×1 PNG

### 结果

- [真实验证] 返回 `code: 0`
- [真实验证] 返回了：
  - `data.type=image`
  - `data.fileName`
  - `data.size`
  - `data.download_url`

### 结论

- [真实验证] 上传接口可作为第二步最小联调验证
- [交叉整理] `fileName` 是后续任务回填时最关键的字段

## 2026-03-08：状态接口

### 请求 1

- 接口：`POST /task/openapi/status`
- 参数：`taskId=0`

### 结果 1

- [真实验证] 返回：

```json
{
  "code": 301,
  "msg": "taskId must be positive",
  "data": null
}
```

### 请求 2

- 接口：`POST /task/openapi/status`
- 参数：不存在的正整数 `taskId`

### 结果 2

- [真实验证] 仅 Body `apiKey`：`807 APIKEY_TASK_NOT_FOUND`
- [真实验证] 仅 Header：`301 must not be blank`

### 结论

- [真实验证] 状态接口同样强依赖 Body 中的 `apiKey`
- [交叉整理] 仅靠 Authorization Header 不能稳定替代 Body 参数

## 2026-03-08：结果接口

### 请求

- 接口：`POST /task/openapi/outputs`
- 参数：不存在的正整数 `taskId`

### 结果

- [真实验证] 返回：

```json
{
  "code": 807,
  "msg": "APIKEY_TASK_NOT_FOUND",
  "data": null
}
```

### 结论

- [真实验证] 结果接口对不存在任务会给出明确的 `807`

## 2026-03-08：V2 查询接口

### 请求

- 接口：`POST /openapi/v2/query`
- 参数：不存在的正整数 `taskId`

### 结果

- [真实验证] 带鉴权时返回结构为：
  - `taskId`
  - `status`
  - `errorCode`
  - `errorMessage`
  - `results`
  - `clientId`
  - `promptTips`
  - `failedReason`
  - `usage`

- [真实验证] 不带鉴权时返回：

```json
{
  "code": 412,
  "msg": "TOKEN_INVALID"
}
```

### 结论

- [真实验证] V2 查询接口的错误结构与旧版 `code/msg/data` 风格不同
- [交叉整理] 如果你要同时支持 V1 / V2 查询，需要在解析层做分流

## 2026-03-08：AI 应用 demo 接口

### 请求

- 接口：`GET /api/webapp/apiCallDemo`
- 输入：真实 `webappId`

### 结果

- [真实验证] 四个目标 AI 应用都可通过该接口拿到 `nodeInfoList`
- [真实验证] 这四个页面型 AI 应用都可以直接用 `webappId + nodeInfoList` 调 `POST /task/openapi/ai-app/run`
- [真实验证] 当前公开 demo 数据中未发现可直接依赖的 `quickCreateCode`

### 结论

- [真实验证] 对页面型 AI 应用接入来说，`apiCallDemo` 是最关键的模板接口
- [交叉整理] 如果你要替代官网“API调用示例”，优先缓存 demo JSON，而不是依赖网页按钮行为

## 2026-03-08：四个 AI 应用真实闭环

### 验证范围

- `1994388299756212225` 室内设计平面图填色-立体版
- `1986819253754130433` Missa_建筑景观_风格迁移_效果图专用
- `2003678561775067138` 🍌香蕉 2 & Pro9图任意融合
- `2023563076041183233` 毛坯房出图-全能版

### 结果

- [真实验证] `1994388299756212225`
  - Python `taskId=2030465625113104385`
  - Node `taskId=2030466545649590273`
  - 都成功返回输出
- [真实验证] `1986819253754130433`
  - Python `taskId=2030472866847399938`
  - 成功返回 `2` 个输出
- [真实验证] `2003678561775067138`
  - Python `taskId=2030466557397835777`
  - 使用 `9` 张图 + `1` 条 prompt 成功返回输出
- [真实验证] `2023563076041183233`
  - Python `taskId=2030475511414792193`
  - 使用 `2` 张图 + 文本 + LIST 参数成功返回输出

### 结论

- [真实验证] 这四个 AI 应用都能在本地 SDK 封装下跑通真实闭环
- [真实验证] `2003678561775067138` 的公开模板确实是 9 图版，而不是 2 图版
- [交叉整理] `1994388299756212225` 适合作为 Python / Node 双 SDK 的低门槛 smoke case

## 2026-03-08：`2023563076041183233` 分辨率与余额约束

### 请求

- 接口：`POST /task/openapi/ai-app/run`
- 应用：`2023563076041183233`
- 对比参数：
  - 官方默认 `605:resolution=2k`
  - 验证覆盖 `605:resolution=1k`

### 结果

- [真实验证] `2k` 时返回 `code=433`
- [真实验证] 错误消息核心为“Your API balance is insufficient”
- [真实验证] 保持其他参数不变，仅改成 `1k` 后即可成功提交并完成

### 结论

- [真实验证] 该应用的可用性不仅取决于 `remainCoins`，也受第三方 API 余额约束
- [推断建议] 做自动化验证时，最好允许 manifest 对 LIST 节点做账户级覆盖
- [推断建议] 若账户没有第三方余额，优先从较低分辨率开始验证


---

# 13-Python-Sdk

# Python SDK

## 目标

这套 Python SDK 面向 RunningHub AI 应用调用与任务轮询场景，覆盖以下常用能力：

- 账户检查
- 二进制文件上传
- AI 应用 demo 获取
- AI 应用任务发起
- 任务状态查询
- 任务结果查询
- V2 查询补偿
- 等待任务完成并落盘

实现文件位于：

- `assets/sdk/python/runninghub_client.py`
- `assets/sdk/python/quick_create_client.py`
- `assets/sdk/python/app_presets.py`
- `assets/sdk/python/examples/run_app.py`

## 运行要求

- Python `3.10+`
- 依赖 `requests`
- 使用环境变量 `RUNNINGHUB_API_KEY`

## 模块说明

### `runninghub_client.py`

底层 HTTP 客户端，负责：

- 统一请求头构造
- JSON 接口请求
- 上传接口调用
- API 错误封装
- JSON 结果落盘

公开内容：

- `RunningHubApiError`
- `mask_api_key(api_key, visible=4)`
- `RunningHubClient`

核心方法：

- `check_account(include_auth=True, include_body=True)`
- `get_ai_app_demo(webapp_id, include_auth=True)`
- `upload_file(file_path)`
- `run_ai_app(webapp_id, node_info_list, webhook_url=None, instance_type=None)`
- `query_status(task_id, include_auth=True, include_body_api_key=True)`
- `query_outputs(task_id, include_auth=True, include_body_api_key=True)`
- `query_v2(task_id, include_auth=True)`
- `save_json(path, payload)`

### `quick_create_client.py`

面向 AI 应用的编排层，负责：

- 从 demo 中提取 `nodeInfoList`
- 按 `nodeId:fieldName` 覆盖节点值
- 发起 AI 应用任务
- 轮询任务直至完成
- 在失败时抛出结构化异常

公开内容：

- `RunningHubTaskFailure`
- `node_lookup_key(node)`
- `clone_nodes(node_info_list)`
- `apply_node_overrides(node_info_list, overrides)`
- `AiAppRunner`

### `app_presets.py`

内置四个 AI 应用 preset：

- `1994388299756212225` 室内设计平面图填色-立体版
- `1986819253754130433` Missa_建筑景观_风格迁移_效果图专用
- `2003678561775067138` 🍌香蕉 2 & Pro9图任意融合
- `2023563076041183233` 毛坯房出图-全能版

公开内容：

- `APP_PRESETS`
- `load_demo_json(app_id)`
- `build_app_overrides(app_id, uploaded_assets, prompt=None)`
- `list_supported_app_ids()`

## 基础示例

```python
from app_presets import build_app_overrides
from quick_create_client import AiAppRunner
from runninghub_client import RunningHubClient

client = RunningHubClient(api_key=os.environ["RUNNINGHUB_API_KEY"])
runner = AiAppRunner(client)

upload = client.upload_file("./demo-floorplan.png")
file_name = upload["data"]["fileName"]

node_overrides = build_app_overrides(
    "1994388299756212225",
    uploaded_assets=[file_name],
)

result = runner.run_and_wait(
    "1994388299756212225",
    node_overrides=node_overrides,
    poll_interval=12,
    timeout_seconds=1800,
)

print(result["final"])
```

## CLI 示例

```bash
export RUNNINGHUB_API_KEY="你的apikey"
PYTHONPATH=skills/runninghub-api-dev/assets/sdk/python \
python skills/runninghub-api-dev/assets/sdk/python/examples/run_app.py \
  --app-id 1994388299756212225 \
  --file ./demo-floorplan.png \
  --save-json ./result.json
```

常用参数：

- `--app-id`：目标应用 ID
- `--file`：本地输入文件，可重复传入
- `--prompt`：覆盖默认提示词
- `--poll-interval`：轮询间隔，单位秒
- `--timeout-seconds`：超时，单位秒
- `--save-json`：保存结果 JSON

## 与验证脚本的关系

真实闭环验证脚本直接复用这套 SDK：

- `scripts/validate/run_python_app_validation.sh`

它会：

- 读取 `assets/test-inputs/manifest.json`
- 上传本地测试素材
- 按 preset + `nodeOverrides` 组装 `nodeInfoList`
- 发起真实 AI 应用任务
- 轮询到完成后写入 `assets/validation/app-<id>-python.json`

## 已验证能力

截至 `2026-03-08`，这套 Python SDK 已完成：

- 4 个目标 AI 应用的真实闭环调用
- `1994388299756212225` 的单图闭环
- `1986819253754130433` 的双图风格迁移闭环
- `2003678561775067138` 的 9 图融合闭环
- `2023563076041183233` 的双图 + LIST 参数闭环

详细结果见：

- `references/15-ai-app-validation.md`
- `assets/validation/summary.json`

## 测试

Python 侧单元测试位于：

- `assets/sdk/python/tests/test_runninghub_client.py`
- `assets/sdk/python/tests/test_quick_create_client.py`
- `assets/sdk/python/tests/test_app_presets.py`

建议验证命令：

```bash
PYTHONPATH=skills/runninghub-api-dev/assets/sdk/python \
python -m unittest discover -s skills/runninghub-api-dev/assets/sdk/python/tests -v

python -m py_compile \
  skills/runninghub-api-dev/assets/sdk/python/runninghub_client.py \
  skills/runninghub-api-dev/assets/sdk/python/quick_create_client.py \
  skills/runninghub-api-dev/assets/sdk/python/app_presets.py \
  skills/runninghub-api-dev/assets/sdk/python/examples/run_app.py
```

## 注意点

- 账户接口、状态接口、结果接口都不应只依赖 Authorization Header，Body 中的 `apikey/apiKey` 仍要按接口要求传
- AI 应用 demo 返回的 `curl` 示例中可能包含调用时的真实 `apiKey` 占位；本仓库已统一脱敏为 `<RUNNINGHUB_API_KEY>`
- `2023563076041183233` 官方 demo 默认 `2k`，但当前验证账户在 `2k` 档位会触发第三方余额不足；验证时使用 `1k` 覆盖参数，见 `assets/test-inputs/manifest.json`


---

# 14-Node-Sdk

# Node.js SDK

## 目标

这套 Node.js SDK 面向 RunningHub AI 应用调用与任务轮询场景，覆盖以下常用能力：

- 账户检查
- 二进制文件上传
- AI 应用 demo 获取
- AI 应用任务发起
- 任务状态查询
- 任务结果查询
- V2 查询补偿
- 等待任务完成并落盘

实现文件位于：

- `assets/sdk/node/runninghub-client.mjs`
- `assets/sdk/node/quick-create-client.mjs`
- `assets/sdk/node/app-presets.mjs`
- `assets/sdk/node/examples/run-app.mjs`

## 运行要求

- Node.js `18+`
- 推荐 Node.js `20+`
- 依赖内建 `fetch`、`FormData`、`Blob`
- 使用环境变量 `RUNNINGHUB_API_KEY`

## 模块说明

### `runninghub-client.mjs`

底层 HTTP 客户端，负责：

- 统一请求头构造
- JSON 接口请求
- 上传接口调用
- API 错误封装
- JSON 结果落盘

公开内容：

- `RunningHubApiError`
- `maskApiKey(apiKey, visible = 4)`
- `RunningHubClient`

核心方法：

- `buildHeaders(options)`
- `checkAccount(options)`
- `getAiAppDemo(webappId, options)`
- `uploadFile(filePath)`
- `runAiApp({ webappId, nodeInfoList, webhookUrl, instanceType })`
- `queryStatus(taskId, options)`
- `queryOutputs(taskId, options)`
- `queryV2(taskId, options)`
- `saveJson(filePath, payload)`

### `quick-create-client.mjs`

面向 AI 应用的编排层，负责：

- 从 demo 中提取 `nodeInfoList`
- 按 `nodeId:fieldName` 覆盖节点值
- 发起 AI 应用任务
- 轮询任务直至完成
- 在失败时抛出结构化异常

公开内容：

- `RunningHubTaskFailure`
- `nodeLookupKey(node)`
- `cloneNodes(nodeInfoList)`
- `applyNodeOverrides(nodeInfoList, overrides)`
- `AiAppRunner`

### `app-presets.mjs`

内置四个 AI 应用 preset：

- `1994388299756212225` 室内设计平面图填色-立体版
- `1986819253754130433` Missa_建筑景观_风格迁移_效果图专用
- `2003678561775067138` 🍌香蕉 2 & Pro9图任意融合
- `2023563076041183233` 毛坯房出图-全能版

公开内容：

- `APP_PRESETS`
- `loadDemoJson(appId)`
- `buildAppOverrides(appId, { uploadedAssets, prompt })`
- `listSupportedAppIds()`

## 基础示例

```js
import { RunningHubClient } from './assets/sdk/node/runninghub-client.mjs';
import { AiAppRunner } from './assets/sdk/node/quick-create-client.mjs';
import { buildAppOverrides } from './assets/sdk/node/app-presets.mjs';

const client = new RunningHubClient({
  apiKey: process.env.RUNNINGHUB_API_KEY,
});

const runner = new AiAppRunner(client);

const upload = await client.uploadFile('./demo-floorplan.png');
const fileName = upload.data.fileName;

const nodeOverrides = buildAppOverrides('1994388299756212225', {
  uploadedAssets: [fileName],
});

const result = await runner.runAndWait('1994388299756212225', {
  nodeOverrides,
  pollIntervalMs: 12_000,
  timeoutMs: 1_800_000,
});

console.log(result.final);
```

## CLI 示例

```bash
export RUNNINGHUB_API_KEY="你的apikey"
node skills/runninghub-api-dev/assets/sdk/node/examples/run-app.mjs \
  --app-id 1994388299756212225 \
  --file ./demo-floorplan.png \
  --poll-interval-seconds 12 \
  --timeout-seconds 1800 \
  --save-json ./result.json
```

常用参数：

- `--app-id`：目标应用 ID
- `--file`：本地输入文件，可重复传入
- `--prompt`：覆盖默认提示词
- `--poll-interval-seconds` / `--poll-interval-ms`：轮询间隔
- `--timeout-seconds` / `--timeout-ms`：超时
- `--save-json`：保存结果 JSON

## 与验证脚本的关系

Node 侧提供独立真实验证入口：

- `scripts/validate/run_node_app_validation.sh`

它会：

- 读取 `assets/test-inputs/manifest.json`
- 上传本地测试素材
- 按 preset + `nodeOverrides` 组装 `nodeInfoList`
- 发起真实 AI 应用任务
- 轮询到完成后写入 `assets/validation/app-<id>-node.json`

## 已验证能力

截至 `2026-03-08`，Node 侧已完成：

- `1994388299756212225` 的真实闭环调用
- 上传 → 发起任务 → 轮询 → 结果落盘整链路验证

详细结果见：

- `assets/validation/app-1994388299756212225-node.json`
- `references/15-ai-app-validation.md`

## 错误处理建议

- 账户校验异常：优先检查 `Authorization` 和 body 中的 `apikey/apiKey` 是否都符合接口要求
- 上传异常：优先确认文件存在、文件大小、上传结果中的 `data.fileName`
- 任务发起异常：优先核对 `webappId` 与 `nodeInfoList`
- 轮询异常：优先记录 `status`、`outputs`、`queryV2` 三份原始响应
- 产物落盘前必须脱敏，仓库中统一使用 `<RUNNINGHUB_API_KEY>`

## 测试

Node 侧使用 `node:test`，测试文件位于：

- `assets/sdk/node/tests/runninghub-client.test.mjs`
- `assets/sdk/node/tests/quick-create-client.test.mjs`
- `assets/sdk/node/tests/app-presets.test.mjs`

建议验证命令：

```bash
node --test skills/runninghub-api-dev/assets/sdk/node/tests/*.test.mjs

node --check skills/runninghub-api-dev/assets/sdk/node/runninghub-client.mjs
node --check skills/runninghub-api-dev/assets/sdk/node/quick-create-client.mjs
node --check skills/runninghub-api-dev/assets/sdk/node/app-presets.mjs
node --check skills/runninghub-api-dev/assets/sdk/node/examples/run-app.mjs
```


---

# 15-Ai-App-Validation

# 四个 AI 应用真实闭环验证

## 结论先看

截至 `2026-03-08`，目标四个 AI 应用都已经完成至少一次真实闭环：

- `1986819253754130433`：Python SDK 成功
- `1994388299756212225`：Python SDK 成功，Node SDK 也成功
- `2003678561775067138`：Python SDK 成功
- `2023563076041183233`：Python SDK 成功

完整汇总见：

- `assets/validation/summary.json`

单次执行原始记录见：

- `assets/validation/app-1986819253754130433-python.json`
- `assets/validation/app-1994388299756212225-python.json`
- `assets/validation/app-1994388299756212225-node.json`
- `assets/validation/app-2003678561775067138-python.json`
- `assets/validation/app-2023563076041183233-python.json`

## 测试素材策略

素材来源以公网可访问图片为主，优先顺序如下：

1. RunningHub 官方 AI 应用详情页公开 `covers`
2. 在 `covers` 基础上做本地裁切，构造更贴近节点语义的最小素材
3. 对 9 图融合应用补齐多张部件级参考图

素材清单入口：

- `assets/test-inputs/manifest.json`

实际本地素材位于：

- `assets/test-inputs/`

## 验证方法

### Python

逐个应用执行：

```bash
RUNNINGHUB_API_KEY=你的apikey \
skills/runninghub-api-dev/scripts/validate/run_python_app_validation.sh <app-id>
```

### Node

Node 真实闭环入口：

```bash
RUNNINGHUB_API_KEY=你的apikey \
skills/runninghub-api-dev/scripts/validate/run_node_app_validation.sh 1994388299756212225
```

### 汇总

```bash
python skills/runninghub-api-dev/scripts/validate/build_validation_summary.py
```

## 分应用结果

### `1994388299756212225` 室内设计平面图填色-立体版

- 实测 SDK：
  - Python
  - Node
- 实测任务：
  - Python `taskId=2030465625113104385`
  - Node `taskId=2030466545649590273`
- 输入：
  - 1 张平面白图
  - 1 条文本提示词
  - `260:width=1600`
  - `260:height=1600`
- 结果：
  - 两次闭环都成功
  - 输出数量均为 `1`
- 价值：
  - 同时验证了 Python/Node 两套 SDK 的上传、任务发起、轮询与结果解析

### `1986819253754130433` Missa_建筑景观_风格迁移_效果图专用

- 实测 SDK：Python
- 实测任务：`taskId=2030472866847399938`
- 输入：
  - 2 张图片
  - 不传 prompt
- 结果：
  - 闭环成功
  - 输出数量为 `2`
- 价值：
  - 证明公开 demo 的双图输入模板可直接用于真实调用
  - 证明此应用不依赖文本 prompt 也能完成执行

### `2003678561775067138` 🍌香蕉 2 & Pro9图任意融合

- 实测 SDK：Python
- 实测任务：`taskId=2030466557397835777`
- 输入：
  - 9 张图片
  - 1 条中文 prompt
- 结果：
  - 闭环成功
  - 输出数量为 `1`
- 价值：
  - 证明公开模板暴露的 9 图输入槽位是真实可运行的
  - 证明官方封面裁切出的 9 张局部参考图足以完成接口闭环验证

### `2023563076041183233` 毛坯房出图-全能版

- 实测 SDK：Python
- 实测任务：`taskId=2030475511414792193`
- 输入：
  - 2 张图片
  - 1 条中文 prompt
  - LIST 参数：
    - `605:aspectRatio=auto`
    - `605:resolution=1k`
    - `605:channel=Third-party`
- 结果：
  - 闭环成功
  - 输出数量为 `1`
- 关键实测差异：
  - 官方 demo 默认 `605:resolution=2k`
  - 当前验证账户在 `2k` 下返回 `code=433`
  - 错误核心是第三方 API 余额不足
  - 改成 `1k` 后即可成功提交并完成
- 价值：
  - 证明这个应用的 LIST 节点参数必须纳入真实工程验证
  - 证明默认值不一定适合所有账户余额状态

## 关键工程结论

- `GET /api/webapp/apiCallDemo` 足以提取四个 AI 应用的真实 `nodeInfoList` 模板
- `POST /task/openapi/ai-app/run` 可直接用于这四个页面型 AI 应用，不需要 `quickCreateCode`
- `1986819253754130433` 的最小输入就是两张图
- `2003678561775067138` 当前公开模板就是 9 图版，不应假设 2 图即可跑通
- `2023563076041183233` 虽然官网默认 `2k`，但实际可用性受当前账户第三方余额影响
- 真实产物保存前必须脱敏；本仓库中的 `apiKey` 统一替换成 `<RUNNINGHUB_API_KEY>`

## 推荐使用方式

如果你的目标是复制这套闭环：

1. 先看 `assets/test-inputs/manifest.json`
2. 再看 `references/13-python-sdk.md` 或 `references/14-node-sdk.md`
3. 用 `scripts/validate/run_python_app_validation.sh` 先跑 Python
4. 如果还要验证 JS 调用链，再跑 `scripts/validate/run_node_app_validation.sh`

如果你的目标是直接抄现成结论：

- 看 `assets/validation/summary.json`
- 再进入对应 `app-*.json` 查看当次上传文件、节点覆盖值和输出结构


---

# Auth-And-Account

# 鉴权与账号校验

## 最小验证接口

最推荐的首个真实联调接口：

- 方法：`POST`
- 路径：`/uc/openapi/accountStatus`
- 完整地址：`https://www.runninghub.cn/uc/openapi/accountStatus`

原因：

- 只读
- 不创建任务
- 不需要 `workflowId`
- 不需要上传文件
- 能快速确认 API Key、账户权限、账户类型

## 鉴权规则

RunningHub 多数接口都建议同时传两处密钥：

1. Header

```http
Authorization: Bearer <RUNNINGHUB_API_KEY>
Host: www.runninghub.cn
Content-Type: application/json
```

2. Body

```json
{
  "apikey": "<RUNNINGHUB_API_KEY>"
}
```

或：

```json
{
  "apiKey": "<RUNNINGHUB_API_KEY>"
}
```

不同接口字段名大小写不完全一致：

- 账户接口常见 `apikey`
- 任务接口常见 `apiKey`

写请求前先核对文档示例。

## 已验证响应

2026-03-08 使用真实 API Key 验证成功，实际返回结构如下：

```json
{
  "code": 0,
  "msg": "success",
  "data": {
    "remainCoins": "76600",
    "currentTaskCounts": "0",
    "remainMoney": null,
    "currency": null,
    "apiType": "NORMAL"
  }
}
```

可重点关注：

- `remainCoins`：剩余 RH 币
- `currentTaskCounts`：当前执行中的任务数
- `apiType`：账号 API 类型

## 最小 curl

```bash
curl -X POST 'https://www.runninghub.cn/uc/openapi/accountStatus' \
  -H 'Host: www.runninghub.cn' \
  -H "Authorization: Bearer ${RUNNINGHUB_API_KEY}" \
  -H 'Content-Type: application/json' \
  -d "{\"apikey\":\"${RUNNINGHUB_API_KEY}\"}"
```

## 接入建议

1. 新项目接入时，先跑一次账户校验
2. 将 Key 放到环境变量 `RUNNINGHUB_API_KEY`
3. 业务日志里不要打印完整 Key
4. 任务流调用前，可用该接口做启动前自检

## 常见失败

- `801 APIKEY_UNSUPPORTED_FREE_USER`
  - 免费用户不支持 API
- `802 APIKEY_UNAUTHORIZED`
  - Key 无效、过期或被禁用
- `412 TOKEN_INVALID`
  - URL 路径写错


---

# Comfyui-Workflows

# ComfyUI 工作流调用

## 先决条件

在写 API 代码之前，先确认：

1. 你已经拿到 `workflowId`
2. 该工作流在网页端至少成功运行过一次
3. 需要改参的字段能在工作流 / API JSON 中找到真实 `nodeId` 与 `fieldName`

## 两种调用方式

### 1. 简易模式

- 接口：`POST /task/openapi/create`
- 适合：不改任何参数，直接按网页默认配置运行

最小请求体通常只需要：

```json
{
  "apiKey": "your-api-key",
  "workflowId": "1904136902449209346"
}
```

### 2. 高级模式

- 接口：`POST /task/openapi/create`
- 适合：提交时动态修改节点参数

文档中的典型请求体：

```json
{
  "apiKey": "your-api-key",
  "workflowId": "1904136902449209346",
  "nodeInfoList": [
    {
      "nodeId": "6",
      "fieldName": "text",
      "fieldValue": "1 girl in classroom"
    },
    {
      "nodeId": "3",
      "fieldName": "seed",
      "fieldValue": "1231231"
    }
  ]
}
```

## `nodeInfoList` 的核心规则

每一项都表示“改某个节点的某个输入字段”：

- `nodeId`：节点编号
- `fieldName`：该节点输入字段名
- `fieldValue`：新的值

参考文档说明：

- 文本节点常见 `fieldName=text`
- 随机种子常见 `fieldName=seed`
- 图片输入常见 `fieldName=image`

## 快速定位 `nodeId / fieldName`

1. 打开工作流界面，记下节点右上角数字
2. 导出 / 查看 API 格式工作流 JSON
3. 在 JSON 中搜索这个节点编号
4. 在对应 `inputs` 中找到 key 名称，这个 key 就是 `fieldName`

## 高级参数

### `webhookUrl`

任务完成后，RunningHub 会主动 `POST` 回调。

典型回调：

```json
{
  "event": "TASK_END",
  "taskId": "1904163390028185602",
  "eventData": "{\"code\":0,\"msg\":\"success\",\"data\":[{\"fileUrl\":\"https://...png\",\"fileType\":\"png\",\"taskCostTime\":0,\"nodeId\":\"9\"}]}"
}
```

### `workflow`

- 可直接提交完整工作流 JSON 字符串
- 如果指定该字段，文档说明会忽略 `workflowId`

### `instanceType`

- 可指定实例类型
- 文档示例里出现过 `"plus"`

### `usePersonalQueue`

- 仅对独占类型 Key 生效
- 开启后会进入个人排队

## 返回结果

成功时通常会得到：

```json
{
  "code": 0,
  "msg": "success",
  "data": {
    "taskId": "1904163390028185602"
  }
}
```

不同接口 / 场景下，`data` 中还可能附带：

- `netWssUrl`
- `clientId`
- `taskStatus`
- `promptTips`

## 开发建议

1. 把 `workflowId` 固化到配置层
2. 把 `nodeInfoList` 构造逻辑封装成函数
3. 对 `seed` 做显式控制，不要假设平台会保持原值
4. 对图片、音频、视频输入统一走上传→回填流程
5. 如果是产品环境，优先 webhook；如果是脚本联调，优先轮询


---

# Errors-And-Debugging

# 错误码与排障

## 高优先级错误码

这些错误最值得优先处理：

- `301 PARAMS_INVALID`
  - 缺参数、类型不对、字段名不对
- `380 WORKFLOW_NOT_EXISTS`
  - `workflowId` 无效
- `412 TOKEN_INVALID`
  - URL 路径拼错
- `415 TASK_INSTANCE_MAXED`
  - 独占型机器暂时不足
- `801 APIKEY_UNSUPPORTED_FREE_USER`
  - 免费用户不支持 API
- `802 APIKEY_UNAUTHORIZED`
  - API Key 无效或失效
- `803 APIKEY_INVALID_NODE_INFO`
  - `nodeInfoList` 与工作流不匹配
- `804 APIKEY_TASK_IS_RUNNING`
  - 任务仍在运行
- `805 APIKEY_TASK_STATUS_ERROR`
  - 任务异常，可继续看失败详情
- `807 APIKEY_TASK_NOT_FOUND`
  - `taskId` 不存在
- `808 APIKEY_UPLOAD_FAILED`
  - 上传失败
- `809 APIKEY_FILE_SIZE_EXCEEDED`
  - 文件过大
- `813 APIKEY_TASK_IS_QUEUED`
  - 已排队

## 最高频排查顺序

1. **先查 URL**
   - `412 TOKEN_INVALID` 通常不是鉴权问题，而是接口路径错误

2. **再查 Key**
   - 用账户接口验证是否能成功返回 `code: 0`

3. **再查工作流前提**
   - 工作流是否存在
   - 是否网页端先跑通过一次

4. **最后查 `nodeInfoList`**
   - `nodeId` 对不对
   - `fieldName` 对不对
   - `fieldValue` 类型对不对

## `nodeInfoList` 排查技巧

文档给出的关键提醒：

1. API 调用会强制重置 `seed`
   - 如果你想保持种子值，必须显式把 `seed` 放进 `nodeInfoList`

2. 某些字段属于前端逻辑
   - 在 API 格式工作流里找不到，就不要硬传

3. `fieldValue` 如果是 `[]` 包裹的连线结构
   - 一般不建议修改

## 失败时该记录什么

为方便二次排障，建议日志里至少记录：

- 请求 URL
- `workflowId` / `webappId`
- `taskId`
- `code`
- `msg`
- 失败时的 `failedReason.exception_message`
- 失败时的 `failedReason.node_name`

不要记录完整 API Key。


---

# Quick-Create

# 快捷创作调用

## 适用场景

当你不是直接面向某个 `workflowId`，而是要调用 RunningHub 平台“快捷创作”页面里的现成能力时，走这条路线。

## 核心接口

- 方法：`POST`
- 路径：`/task/openapi/quick-ai-app/run`

## 关键入参

文档与接口示例显示，这类调用通常需要：

- `webappId`
- `apiKey`
- `quickCreateCode`
- `nodeInfoList`

典型结构：

```json
{
  "webappId": "196********290",
  "apiKey": "*********************",
  "quickCreateCode": "***",
  "nodeInfoList": [
    {
      "nodeId": "2",
      "nodeName": "LoadImage",
      "fieldName": "image",
      "fieldType": "IMAGE",
      "fieldValue": "61a52873b2f16cf3734dad1d20f704d32ca5f1d77896847f27a1e1ee72eb626d.jpg",
      "description": "上传图像"
    }
  ]
}
```

## 参数来源

官方文档建议：

1. 登录 RunningHub
2. 进入对应快捷创作模块页面
3. 点击“调用 API”
4. 从页面示例中直接取得：
   - `webappId`
   - `quickCreateCode`
   - `nodeInfoList`

也就是说，快捷创作接口的最佳实践不是“自己猜参数”，而是**从页面现成示例回填**。

## `nodeInfoList` 与 ComfyUI 的区别

快捷创作里的 `nodeInfoList` 往往更完整，除了常见字段，还会出现：

- `nodeName`
- `fieldType`
- `description`

常见 `fieldType` 包括：

- `STRING`
- `INT`
- `SWITCH`
- `LORA`
- `IMAGE`

## 何时选快捷创作

- 目标能力已经在 RunningHub 平台现成存在
- 页面已经提供了可复制的 API 示例
- 你不想维护底层 ComfyUI 工作流细节

## 何时不要选快捷创作

- 你需要完全控制工作流结构
- 你已经有成熟的 `workflowId` 接入方案
- 你需要复用自定义 ComfyUI 工作流节点逻辑

## 返回结果

成功时文档示例通常包含：

- `taskId`
- `netWssUrl`
- `clientId`
- `taskStatus`
- `promptTips`

后续查询状态与结果，仍然沿用通用任务查询接口。


---

# Task-Lifecycle

# 任务状态、结果与 webhook

## 推荐时序

```text
校验账号
  ↓
准备上传资源（如需要）
  ↓
创建任务
  ↓
查询状态 / 等 webhook
  ↓
查询结果
```

## 查询任务状态

- 方法：`POST`
- 路径：`/task/openapi/status`

请求体：

```json
{
  "apiKey": "your-api-key",
  "taskId": "1904152026220003329"
}
```

文档中状态枚举：

- `QUEUED`
- `RUNNING`
- `FAILED`
- `SUCCESS`

### 已验证错误场景

2026-03-08 实测：

- `taskId=0`

```json
{
  "code": 301,
  "msg": "taskId must be positive",
  "data": null
}
```

- 不存在的正整数 `taskId`

```json
{
  "code": 807,
  "msg": "APIKEY_TASK_NOT_FOUND",
  "data": null
}
```

## 查询任务生成结果

- 方法：`POST`
- 路径：`/task/openapi/outputs`

成功示例：

```json
{
  "code": 0,
  "msg": "success",
  "data": [
    {
      "fileUrl": "https://...png",
      "fileType": "png",
      "taskCostTime": "83",
      "nodeId": "12",
      "consumeCoins": "17"
    }
  ]
}
```

### 非成功结果也要处理

文档给出了几种高频返回：

- `804 APIKEY_TASK_IS_RUNNING`
  - 任务还在运行，继续轮询
- `813 APIKEY_TASK_IS_QUEUED`
  - 任务在排队，继续等待
- `805 APIKEY_TASK_STATUS_ERROR`
  - 任务失败，可从 `data.failedReason` 读取详细错误

失败示例里可拿到：

- `node_name`
- `node_id`
- `exception_type`
- `exception_message`
- `traceback`

这对定位工作流节点问题很有帮助。

## V2 查询接口

文档还给出了：

- `POST /openapi/v2/query`

如果你在新项目里统一走较新接口，可以额外评估这一版，但不要在没有确认字段兼容性的前提下替换老轮询逻辑。

## webhook 使用建议

创建任务时传 `webhookUrl` 后，平台会在任务结束时回调。

处理建议：

1. 接口收到回调后先快速返回 200
2. 再异步解析 `eventData`
3. 做去重，避免平台重试造成重复消费
4. 将 `taskId` 作为幂等键


---

# Uploads

# 文件上传与资源回填

## 推荐上传接口

优先使用新版接口：

- 方法：`POST`
- 路径：`/openapi/v2/media/upload/binary`

## 请求方式

Header：

```http
Host: www.runninghub.cn
Authorization: Bearer <RUNNINGHUB_API_KEY>
```

Body：

- `multipart/form-data`
- 字段名：`file`

## 已验证上传结果

2026-03-08 实测上传 1×1 PNG 成功，得到：

```json
{
  "code": 0,
  "msg": "success",
  "data": {
    "type": "image",
    "download_url": "https://...",
    "fileName": "openapi/c01aef53014548b229559cc463950d343da4469558a2f9c66b32669a7afeeebf.png",
    "size": "68"
  }
}
```

## 回填规则

提交工作流时，通常要把上传返回的 `fileName` 回填到 `nodeInfoList.fieldValue`。

例如：

### 图片

```json
{
  "nodeId": "14",
  "fieldName": "image",
  "fieldValue": "api/9d77b8530f8b3591edc5c4e8f3f55b2cf0960bb2ca35c04e32c1677687866576.png"
}
```

### 音频

```json
{
  "nodeId": "2",
  "fieldName": "audio",
  "fieldValue": "api/7a2f4c8d1e5b9g3h6j0k2l7m4n8p1q3r5s9t0u2v4w6x8y0z1.mp3"
}
```

### 视频

```json
{
  "nodeId": "7",
  "fieldName": "video",
  "fieldValue": "api/14c585a56d8f7c3b9c1ad3c4f8edc93a9fd9f79e21b4d10afd811322bf65f3c2.mp4"
}
```

## 注意事项

1. 回填 `fileName`，不要回填 `download_url`
2. 上传成功后再创建任务，避免任务侧报资源不存在
3. 不同节点的 `fieldName` 不同，图片常见是 `image`，但要以工作流定义为准
4. 大文件、压缩包要关注大小限制与上传失败重试


---
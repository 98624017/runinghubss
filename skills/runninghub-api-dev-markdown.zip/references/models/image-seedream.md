# seedream

- [交叉整理] 本页汇总同一模型族的官网接口，便于替代官网逐页检索。
- [交叉整理] 接口数量：`4`

## 收录接口

- [官网明确] `seedream-v4.5-文生图` → `references/endpoints/408103823-seedream-v4.5-文生图.md`
- [官网明确] `seedream-v4-文生图` → `references/endpoints/408105506-seedream-v4-文生图.md`
- [官网明确] `seedream-v4.5-图生图` → `references/endpoints/408103923-seedream-v4.5-图生图.md`
- [官网明确] `seedream-v4-图生图` → `references/endpoints/408105799-seedream-v4-图生图.md`

## 开发建议

- [交叉整理] 同一模型族的接口通常共享鉴权、异步任务查询和结果获取逻辑。
- [推断建议] 新接入时优先选择描述更完整、示例更清晰的端点做第一条链路验证。

## 验证状态

- [推断建议] 本模型族默认先做文档归档；只有高价值接口才进入真实验证。
